import daemonPy from '../../Linux/Activity-Tracker/daemon.py?raw';
import dashboardPy from '../../Linux/Activity-Tracker/dashboard.py?raw';
import corePy from '../../Linux/Activity-Tracker/vibewatch_core.py?raw';
import setupPy from '../../Linux/Activity-Tracker/setup.py?raw';
import requirementsTxt from '../../Linux/Activity-Tracker/requirements.txt?raw';
import testPy from '../../Linux/Activity-Tracker/test_vibewatch.py?raw';
import readmeMd from '../../Linux/Activity-Tracker/README.md?raw';

export interface LinuxSourceFile {
  name: string;
  path: string;
  role: string;
  content: string;
}

export const LINUX_SOURCE_FILES: LinuxSourceFile[] = [
  {
    name: 'daemon.py',
    path: 'Linux/Activity-Tracker/daemon.py',
    role: 'Headless KDE Plasma 6 Wayland D-Bus + AFK watcher',
    content: daemonPy,
  },
  {
    name: 'dashboard.py',
    path: 'Linux/Activity-Tracker/dashboard.py',
    role: 'Native PyQt6 zero-chrome dashboard & QPainter timeline',
    content: dashboardPy,
  },
  {
    name: 'vibewatch_core.py',
    path: 'Linux/Activity-Tracker/vibewatch_core.py',
    role: 'SQLite WAL DB, 5.0s heartbeat merge, /proc & categories.json',
    content: corePy,
  },
  {
    name: 'setup.py',
    path: 'Linux/Activity-Tracker/setup.py',
    role: '.venv, systemd --user unit & KDE .desktop installer',
    content: setupPy,
  },
  {
    name: 'requirements.txt',
    path: 'Linux/Activity-Tracker/requirements.txt',
    role: 'Lean runtime dependencies (PyQt6, dbus-next, psutil)',
    content: requirementsTxt,
  },
  {
    name: 'test_vibewatch.py',
    path: 'Linux/Activity-Tracker/test_vibewatch.py',
    role: 'Python unittest suite for core & setup renderers',
    content: testPy,
  },
  {
    name: 'README.md',
    path: 'Linux/Activity-Tracker/README.md',
    role: 'Architecture & KDE Plasma 6 installation guide',
    content: readmeMd,
  },
];
