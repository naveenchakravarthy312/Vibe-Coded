import { ActivityEvent } from './activityEngine';

export const ANCHOR_TODAY = new Date(2026, 10, 22, 12, 0, 0, 0); // Sun, Nov 22, 2026

interface BlockSpec {
  startHour: number; // e.g., 8.5 = 08:30
  durationMin: number;
  app_binary: string;
  wm_class: string;
  window_title: string;
  is_afk?: boolean;
}

const TODAY_BLOCKS: BlockSpec[] = [
  {
    startHour: 8.2,
    durationMin: 32,
    app_binary: 'konsole',
    wm_class: 'org.kde.konsole',
    window_title: 'naveen@archlinux: ~/Linux/Activity-Tracker — zsh',
  },
  {
    startHour: 8.75,
    durationMin: 68,
    app_binary: 'antigravity',
    wm_class: 'antigravity',
    window_title: 'daemon.py — VibeWatch — Antigravity',
  },
  {
    startHour: 9.9,
    durationMin: 24,
    app_binary: 'zen-bin',
    wm_class: 'zen',
    window_title: 'KWin Scripting API — KDE Developer Docs — Zen Browser',
  },
  {
    startHour: 10.35,
    durationMin: 56,
    app_binary: 'antigravity',
    wm_class: 'antigravity',
    window_title: 'dashboard.py — VibeWatch — Antigravity',
  },
  {
    startHour: 11.3,
    durationMin: 28,
    app_binary: 'konsole',
    wm_class: 'org.kde.konsole',
    window_title: 'systemctl --user status vibewatch.service — zsh',
  },
  {
    startHour: 11.8,
    durationMin: 42,
    app_binary: 'afk',
    wm_class: 'org.freedesktop.ScreenSaver',
    window_title: 'Screen Locked / Away (> 3m idle)',
    is_afk: true,
  },
  {
    startHour: 12.55,
    durationMin: 38,
    app_binary: 'zen-bin',
    wm_class: 'zen',
    window_title: 'dbus-next ServiceInterface Reference — GitHub — Zen Browser',
  },
  {
    startHour: 13.2,
    durationMin: 52,
    app_binary: 'code',
    wm_class: 'code',
    window_title: 'vibewatch_core.py — Activity-Tracker — Visual Studio Code',
  },
  {
    startHour: 14.1,
    durationMin: 18,
    app_binary: 'zen-bin',
    wm_class: 'zen',
    window_title: 'SQLite WAL Mode Concurrency Notes — Zen Browser',
  },
  {
    startHour: 14.45,
    durationMin: 40,
    app_binary: 'nvim',
    wm_class: 'org.kde.konsole',
    window_title: 'nvim ~/.config/vibewatch/categories.json',
  },
  {
    startHour: 15.15,
    durationMin: 26,
    app_binary: 'afk',
    wm_class: 'org.freedesktop.ScreenSaver',
    window_title: 'Screen Locked / Away (> 3m idle)',
    is_afk: true,
  },
  {
    startHour: 15.6,
    durationMin: 46,
    app_binary: 'War Thunder',
    wm_class: 'aces',
    window_title: 'War Thunder (Vulkan, 64bit) - In battle',
  },
  {
    startHour: 16.38,
    durationMin: 14,
    app_binary: 'War Thunder',
    wm_class: 'aces',
    window_title: 'War Thunder (Vulkan, 64bit) - Waiting for game',
  },
  {
    startHour: 16.65,
    durationMin: 36,
    app_binary: 'War Thunder',
    wm_class: 'aces',
    window_title: 'War Thunder (Vulkan, 64bit) - Hangar',
  },
  {
    startHour: 17.3,
    durationMin: 34,
    app_binary: 'mpv',
    wm_class: 'mpv',
    window_title: 'KDE Plasma 6 Wayland Architecture Talk.mkv — mpv',
  },
  {
    startHour: 17.95,
    durationMin: 24,
    app_binary: 'dolphin',
    wm_class: 'org.kde.dolphin',
    window_title: '~/.local/share/vibewatch — Dolphin',
  },
  {
    startHour: 18.4,
    durationMin: 44,
    app_binary: 'konsole',
    wm_class: 'org.kde.konsole',
    window_title: 'pytest / unittest — Linux/Activity-Tracker — zsh',
  },
  {
    startHour: 19.2,
    durationMin: 58,
    app_binary: 'code',
    wm_class: 'code',
    window_title: 'ActivityTimelineWidget.py — Activity-Tracker — Visual Studio Code',
  },
  {
    startHour: 20.25,
    durationMin: 28,
    app_binary: 'vlc',
    wm_class: 'vlc',
    window_title: 'Synthwave Coding Mix (FLAC) — VLC media player',
  },
  {
    startHour: 20.8,
    durationMin: 35,
    app_binary: 'zen-bin',
    wm_class: 'zen',
    window_title: 'ArchWiki: systemd/User Services — Zen Browser',
  },
];

// Deterministic templates for prior 29 days so Day / 7 Days / 30 Days views feel rich and coherent
const ARCHETYPE_BLOCKS: BlockSpec[][] = [
  [
    { startHour: 9.0, durationMin: 92, app_binary: 'code', wm_class: 'code', window_title: 'wayland_bridge.py — Visual Studio Code' },
    { startHour: 10.6, durationMin: 36, app_binary: 'zen-bin', wm_class: 'zen', window_title: 'PyQt6 QPainter Performance — Zen Browser' },
    { startHour: 11.3, durationMin: 48, app_binary: 'konsole', wm_class: 'org.kde.konsole', window_title: 'git status && lazygit — zsh' },
    { startHour: 12.2, durationMin: 45, app_binary: 'afk', wm_class: 'org.freedesktop.ScreenSaver', window_title: 'Screen Locked / Away', is_afk: true },
    { startHour: 13.1, durationMin: 84, app_binary: 'antigravity', wm_class: 'antigravity', window_title: 'setup.py — VibeWatch — Antigravity' },
    { startHour: 14.6, durationMin: 42, app_binary: 'zen-bin', wm_class: 'zen', window_title: 'Wayland Protocols Spec — Zen Browser' },
    { startHour: 15.5, durationMin: 35, app_binary: 'ghostty', wm_class: 'com.mitchellh.ghostty', window_title: 'htop · sqlite3 activity.db — ghostty' },
    { startHour: 16.4, durationMin: 64, app_binary: 'War Thunder', wm_class: 'aces', window_title: 'War Thunder (Vulkan, 64bit) - In battle' },
    { startHour: 17.5, durationMin: 18, app_binary: 'War Thunder', wm_class: 'aces', window_title: 'War Thunder (Vulkan, 64bit) - Waiting for game' },
    { startHour: 18.2, durationMin: 40, app_binary: 'mpv', wm_class: 'mpv', window_title: 'Linux Plumbers Conference 2026 — mpv' },
  ],
  [
    { startHour: 8.5, durationMin: 74, app_binary: 'nvim', wm_class: 'org.kde.konsole', window_title: 'nvim daemon.py — konsole' },
    { startHour: 9.8, durationMin: 54, app_binary: 'zen-bin', wm_class: 'zen', window_title: 'KDE Plasma 6.3 Release Notes — Zen Browser' },
    { startHour: 10.8, durationMin: 30, app_binary: 'afk', wm_class: 'org.freedesktop.ScreenSaver', window_title: 'Screen Locked / Away', is_afk: true },
    { startHour: 11.4, durationMin: 88, app_binary: 'antigravity', wm_class: 'antigravity', window_title: 'vibewatch_core.py — Antigravity' },
    { startHour: 13.0, durationMin: 44, app_binary: 'konsole', wm_class: 'org.kde.konsole', window_title: 'journalctl --user -u vibewatch -f' },
    { startHour: 14.0, durationMin: 50, app_binary: 'code', wm_class: 'code', window_title: 'DESKTOP-STYLE.md — Visual Studio Code' },
    { startHour: 15.2, durationMin: 38, app_binary: 'elisa', wm_class: 'org.kde.elisa', window_title: 'Ambient Focus Playlist — Elisa' },
    { startHour: 16.1, durationMin: 72, app_binary: 'Sea of Thieves', wm_class: 'steam_app_1172620', window_title: 'Sea of Thieves (Proton Experimental)' },
    { startHour: 18.0, durationMin: 26, app_binary: 'dolphin', wm_class: 'org.kde.dolphin', window_title: '~/Downloads — Dolphin' },
  ],
  [
    { startHour: 9.4, durationMin: 66, app_binary: 'code', wm_class: 'code', window_title: 'test_vibewatch.py — Visual Studio Code' },
    { startHour: 10.6, durationMin: 48, app_binary: 'ghostty', wm_class: 'com.mitchellh.ghostty', window_title: 'python3 -m unittest -v — ghostty' },
    { startHour: 11.5, durationMin: 52, app_binary: 'zen-bin', wm_class: 'zen', window_title: 'org.freedesktop.ScreenSaver D-Bus Spec — Zen Browser' },
    { startHour: 12.6, durationMin: 38, app_binary: 'afk', wm_class: 'org.freedesktop.ScreenSaver', window_title: 'Screen Locked / Away', is_afk: true },
    { startHour: 13.4, durationMin: 95, app_binary: 'antigravity', wm_class: 'antigravity', window_title: 'dashboard.py — Antigravity' },
    { startHour: 15.2, durationMin: 34, app_binary: 'konsole', wm_class: 'org.kde.konsole', window_title: 'kdotool getactivewindow — zsh' },
    { startHour: 16.0, durationMin: 58, app_binary: 'War Thunder', wm_class: 'aces', window_title: 'War Thunder (Vulkan, 64bit) - In battle' },
    { startHour: 17.2, durationMin: 44, app_binary: 'vlc', wm_class: 'vlc', window_title: 'Lo-Fi Beats — VLC media player' },
  ],
];

export function buildSeedActivityEvents(): ActivityEvent[] {
  const events: ActivityEvent[] = [];
  let nextId = 1;

  for (let dayOffset = 29; dayOffset >= 0; dayOffset--) {
    const dayDate = new Date(
      ANCHOR_TODAY.getFullYear(),
      ANCHOR_TODAY.getMonth(),
      ANCHOR_TODAY.getDate() - dayOffset,
      0,
      0,
      0,
      0
    );
    const dayStartTs = Math.floor(dayDate.getTime() / 1000);
    const template =
      dayOffset === 0
        ? TODAY_BLOCKS
        : ARCHETYPE_BLOCKS[(dayOffset * 7 + 1) % ARCHETYPE_BLOCKS.length];

    // Small deterministic per-day offset so adjacent days are visibly distinct
    const jitterScale = dayOffset === 0 ? 1.0 : 0.85 + ((dayOffset * 13) % 35) / 100;

    for (const blk of template) {
      const startTs = Math.round(dayStartTs + blk.startHour * 3600);
      const durationSec = Math.round(blk.durationMin * 60 * jitterScale);
      events.push({
        id: nextId++,
        start_ts: startTs,
        end_ts: startTs + durationSec,
        app_binary: blk.app_binary,
        wm_class: blk.wm_class,
        window_title: blk.window_title,
        is_afk: Boolean(blk.is_afk),
      });
    }
  }

  return events;
}
