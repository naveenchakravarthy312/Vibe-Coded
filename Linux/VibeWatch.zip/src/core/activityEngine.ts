export type RangeMode = 'day' | '7d' | '30d';

export interface ActivityEvent {
  id: number;
  start_ts: number; // Unix epoch seconds
  end_ts: number; // Unix epoch seconds
  app_binary: string;
  wm_class: string;
  window_title: string;
  is_afk: boolean;
}

export interface CategoryRule {
  name: string;
  color: string;
  pattern: string;
}

export interface CategoryBreakdown {
  category: string;
  color: string;
  duration: number;
  percentage: number;
}

export interface TitleBreakdown {
  window_title: string;
  duration: number;
  percentage: number;
}

export interface AppBreakdown {
  app_binary: string;
  category: string;
  color: string;
  duration: number;
  percentage: number;
  titles: TitleBreakdown[];
}

export interface TimelineSegment {
  start_ts: number;
  end_ts: number;
  app_binary: string;
  window_title: string;
  category: string;
  color: string;
  is_afk: boolean;
}

export interface AnalyticsSnapshot {
  activeSeconds: number;
  afkSeconds: number;
  totalTrackedSeconds: number;
  topCategory: string;
  topCategoryColor: string;
  topApp: string;
  categories: CategoryBreakdown[];
  apps: AppBreakdown[];
  timeline: TimelineSegment[];
}

export const HEARTBEAT_PULSETIME_SECONDS = 5.0;

export const DEFAULT_CATEGORIES: CategoryRule[] = [
  {
    name: 'Coding',
    color: '#88C0D0',
    pattern: 'code|antigravity|agy|cursor|nvim|lazygit|pycharm|android-studio|qtcreator',
  },
  {
    name: 'Browsing',
    color: '#826cb6',
    pattern: 'zen|firefox|brave|chromium|chrome',
  },
  {
    name: 'Gaming',
    color: '#D08770',
    pattern: 'steam_app_|war thunder|aces|beamng|ksp|minecraft|heroic|prism',
  },
  {
    name: 'Terminal',
    color: '#98C379',
    pattern: 'konsole|ghostty|kitty|alacritty|zsh|bash',
  },
  {
    name: 'Media',
    color: '#EBCB8B',
    pattern: 'vlc|elisa|mpv|spotify|youtube|music_player',
  },
  {
    name: 'Uncategorized',
    color: '#6C7086',
    pattern: '.*',
  },
];

const FRIENDLY_ALIASES: Record<string, string> = {
  aces: 'War Thunder',
  steam_app_236390: 'War Thunder',
  steam_app_1172620: 'Sea of Thieves',
};

export function normalizeAppBinary(appBinary: string, wmClass = '', caption = ''): string {
  let raw = (appBinary || '').trim();
  if (raw.includes('.') && !raw.endsWith('.exe') && !raw.startsWith('steam_app_')) {
    const tail = raw.split('.').pop() || raw;
    if (tail.length >= 2) {
      raw = tail;
    }
  }
  const lower = raw.toLowerCase();
  if (FRIENDLY_ALIASES[lower]) {
    return FRIENDLY_ALIASES[lower];
  }
  if (lower === 'aces' || caption.toLowerCase().includes('war thunder')) {
    return 'War Thunder';
  }
  if (!raw && wmClass) {
    return wmClass.includes('.') ? wmClass.split('.').pop() || wmClass : wmClass;
  }
  return raw || 'desktop';
}

/**
 * Heartbeat merge logic (pulsetime = 5.0s):
 * If `(app_binary, wm_class, window_title, is_afk)` matches the last event AND
 * `0 <= (now - last.end_ts) <= pulsetime`, extends `last.end_ts = now` in place.
 * Otherwise appends a new event with `start_ts = now, end_ts = now`.
 */
export function recordHeartbeat(
  events: ActivityEvent[],
  sample: {
    now: number;
    app_binary: string;
    wm_class: string;
    window_title: string;
    is_afk: boolean;
  },
  pulsetime = HEARTBEAT_PULSETIME_SECONDS
): { events: ActivityEvent[]; action: 'merged' | 'inserted' } {
  const normBinary = normalizeAppBinary(sample.app_binary, sample.wm_class, sample.window_title);
  const cleanClass = (sample.wm_class || '').trim();
  const cleanTitle = (sample.window_title || '').trim();

  const last = events[events.length - 1];
  if (
    last &&
    last.app_binary === normBinary &&
    last.wm_class === cleanClass &&
    last.window_title === cleanTitle &&
    last.is_afk === sample.is_afk &&
    sample.now - last.end_ts >= 0 &&
    sample.now - last.end_ts <= pulsetime
  ) {
    const updated = [...events];
    updated[updated.length - 1] = { ...last, end_ts: sample.now };
    return { events: updated, action: 'merged' };
  }

  const nextId = last ? last.id + 1 : 1;
  return {
    events: [
      ...events,
      {
        id: nextId,
        start_ts: sample.now,
        end_ts: sample.now,
        app_binary: normBinary,
        wm_class: cleanClass,
        window_title: cleanTitle,
        is_afk: sample.is_afk,
      },
    ],
    action: 'inserted',
  };
}

export function serializeCategoriesJson(rules: CategoryRule[]): string {
  return JSON.stringify({ categories: rules }, null, 2);
}

export function parseCategoriesJson(jsonText: string): { rules?: CategoryRule[]; error?: string } {
  try {
    const parsed = JSON.parse(jsonText);
    const list = Array.isArray(parsed) ? parsed : parsed?.categories;
    if (!Array.isArray(list) || list.length === 0) {
      return { error: 'JSON must contain a non-empty "categories" array.' };
    }

    const rules: CategoryRule[] = [];
    for (let i = 0; i < list.length; i++) {
      const item = list[i];
      if (!item || typeof item !== 'object') {
        return { error: `Category #${i + 1} must be an object.` };
      }
      const name = String(item.name ?? '').trim();
      const color = String(item.color ?? '').trim();
      const pattern = String(item.pattern ?? '').trim();
      if (!name) return { error: `Category #${i + 1} is missing a "name".` };
      if (!/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(color)) {
        return { error: `Category "${name}" has an invalid hex color "${color}".` };
      }
      if (!pattern) return { error: `Category "${name}" is missing a regex "pattern".` };
      try {
        new RegExp(pattern, 'i');
      } catch (err) {
        return {
          error: `Category "${name}" has an invalid regex: ${err instanceof Error ? err.message : String(err)}`,
        };
      }
      rules.push({ name, color, pattern });
    }

    if (!rules.some((r) => r.name.toLowerCase() === 'uncategorized')) {
      rules.push({ name: 'Uncategorized', color: '#6C7086', pattern: '.*' });
    }

    return { rules };
  } catch (err) {
    return { error: `JSON syntax error: ${err instanceof Error ? err.message : String(err)}` };
  }
}

export function categorizeEvent(
  rules: CategoryRule[],
  appBinary: string,
  wmClass: string,
  windowTitle: string
): { name: string; color: string } {
  const haystack = `${appBinary} ${wmClass} ${windowTitle}`;
  let fallback = { name: 'Uncategorized', color: '#6C7086' };

  for (const rule of rules) {
    if (rule.name.toLowerCase() === 'uncategorized') {
      fallback = { name: rule.name, color: rule.color };
      continue;
    }
    try {
      if (new RegExp(rule.pattern, 'i').test(haystack)) {
        return { name: rule.name, color: rule.color };
      }
    } catch {
      // Skip malformed rule safely
    }
  }
  return fallback;
}

export function formatDuration(seconds: number): string {
  const total = Math.max(0, Math.round(seconds));
  if (total === 0) return '0m';
  if (total < 60) return '< 1m';
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  if (hours > 0) {
    return `${hours}h ${String(minutes).padStart(2, '0')}m`;
  }
  return `${minutes}m`;
}

export function formatClockTime(epochSeconds: number): string {
  const d = new Date(epochSeconds * 1000);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

export function getRangeBounds(anchorDate: Date, mode: RangeMode): { startTs: number; endTs: number } {
  const dayStart = new Date(anchorDate.getFullYear(), anchorDate.getMonth(), anchorDate.getDate(), 0, 0, 0, 0);
  const dayEnd = new Date(dayStart.getTime() + 86400 * 1000);
  let start = dayStart;
  if (mode === '7d') {
    start = new Date(dayStart.getTime() - 6 * 86400 * 1000);
  } else if (mode === '30d') {
    start = new Date(dayStart.getTime() - 29 * 86400 * 1000);
  }
  return {
    startTs: Math.floor(start.getTime() / 1000),
    endTs: Math.floor(dayEnd.getTime() / 1000),
  };
}

export function filterEventsInRange(
  events: ActivityEvent[],
  startTs: number,
  endTs: number
): ActivityEvent[] {
  const result: ActivityEvent[] = [];
  for (const ev of events) {
    if (ev.end_ts < startTs || ev.start_ts > endTs) continue;
    const clampedStart = Math.max(ev.start_ts, startTs);
    const clampedEnd = Math.min(ev.end_ts, endTs);
    if (clampedEnd <= clampedStart) continue;
    result.push({
      ...ev,
      start_ts: clampedStart,
      end_ts: clampedEnd,
    });
  }
  return result.sort((a, b) => a.start_ts - b.start_ts);
}

export function computeAnalytics(
  events: ActivityEvent[],
  rules: CategoryRule[],
  includeAfk: boolean,
  categoryFilter: string | null = null
): AnalyticsSnapshot {
  let activeSeconds = 0;
  let afkSeconds = 0;

  const catTotals = new Map<string, number>();
  const catColors = new Map<string, string>();
  const appTotals = new Map<string, number>();
  const appCatVotes = new Map<string, Map<string, number>>();
  const appTitleTotals = new Map<string, Map<string, number>>();
  const timeline: TimelineSegment[] = [];

  for (const ev of events) {
    const dur = Math.max(0, ev.end_ts - ev.start_ts);
    if (dur <= 0) continue;

    let catName: string;
    let catColor: string;

    if (ev.is_afk) {
      afkSeconds += dur;
      timeline.push({
        start_ts: ev.start_ts,
        end_ts: ev.end_ts,
        app_binary: ev.app_binary,
        window_title: ev.window_title || 'Away / Screen Locked',
        category: 'AFK',
        color: '#2A2A2E',
        is_afk: true,
      });
      if (!includeAfk) continue;
      catName = 'AFK';
      catColor = '#585858';
    } else {
      activeSeconds += dur;
      const matched = categorizeEvent(rules, ev.app_binary, ev.wm_class, ev.window_title);
      catName = matched.name;
      catColor = matched.color;
      timeline.push({
        start_ts: ev.start_ts,
        end_ts: ev.end_ts,
        app_binary: ev.app_binary,
        window_title: ev.window_title,
        category: catName,
        color: catColor,
        is_afk: false,
      });
    }

    catTotals.set(catName, (catTotals.get(catName) ?? 0) + dur);
    catColors.set(catName, catColor);

    if (categoryFilter && catName !== categoryFilter) {
      continue;
    }

    const appKey = ev.is_afk ? 'AFK / Locked' : ev.app_binary;
    appTotals.set(appKey, (appTotals.get(appKey) ?? 0) + dur);

    if (!appCatVotes.has(appKey)) appCatVotes.set(appKey, new Map());
    const votes = appCatVotes.get(appKey)!;
    votes.set(catName, (votes.get(catName) ?? 0) + dur);

    if (!appTitleTotals.has(appKey)) appTitleTotals.set(appKey, new Map());
    const titles = appTitleTotals.get(appKey)!;
    const titleKey = ev.window_title || (ev.is_afk ? 'Idle / Screen Locked' : appKey);
    titles.set(titleKey, (titles.get(titleKey) ?? 0) + dur);
  }

  const totalTrackedSeconds = includeAfk ? activeSeconds + afkSeconds : activeSeconds;
  const catDenom = Array.from(catTotals.values()).reduce((sum, v) => sum + v, 0) || 1;
  const categories: CategoryBreakdown[] = Array.from(catTotals.entries())
    .sort((a, b) => b[1] - a[1])
    .map(([category, duration]) => ({
      category,
      color: catColors.get(category) ?? '#6C7086',
      duration,
      percentage: (duration / catDenom) * 100,
    }));

  const appDenom = Array.from(appTotals.values()).reduce((sum, v) => sum + v, 0) || 1;
  const apps: AppBreakdown[] = Array.from(appTotals.entries())
    .sort((a, b) => b[1] - a[1])
    .map(([app_binary, duration]) => {
      const votes = appCatVotes.get(app_binary)!;
      let dominantCat = 'Uncategorized';
      let bestVote = -1;
      for (const [cName, v] of votes.entries()) {
        if (v > bestVote) {
          bestVote = v;
          dominantCat = cName;
        }
      }
      const titleMap = appTitleTotals.get(app_binary) ?? new Map<string, number>();
      const titleDenom = duration || 1;
      const titles: TitleBreakdown[] = Array.from(titleMap.entries())
        .sort((a, b) => b[1] - a[1])
        .map(([window_title, tDur]) => ({
          window_title,
          duration: tDur,
          percentage: (tDur / titleDenom) * 100,
        }));
      return {
        app_binary,
        category: dominantCat,
        color: catColors.get(dominantCat) ?? '#6C7086',
        duration,
        percentage: (duration / appDenom) * 100,
        titles,
      };
    });

  const nonAfkCats = categories.filter((c) => c.category !== 'AFK');
  const topCategory = nonAfkCats[0]?.category ?? 'None';
  const topCategoryColor = nonAfkCats[0]?.color ?? '#585858';
  const nonAfkApps = apps.filter((a) => a.app_binary !== 'AFK / Locked');
  const topApp = nonAfkApps[0]?.app_binary ?? 'None';

  return {
    activeSeconds,
    afkSeconds,
    totalTrackedSeconds,
    topCategory,
    topCategoryColor,
    topApp,
    categories,
    apps,
    timeline,
  };
}

export function formatAnchorDateLabel(anchorDate: Date, todayDate: Date): string {
  const fmt = new Intl.DateTimeFormat('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  }).format(anchorDate);

  const aDay = new Date(anchorDate.getFullYear(), anchorDate.getMonth(), anchorDate.getDate()).getTime();
  const tDay = new Date(todayDate.getFullYear(), todayDate.getMonth(), todayDate.getDate()).getTime();
  const diffDays = Math.round((tDay - aDay) / 86400000);

  if (diffDays === 0) return `Today · ${fmt}`;
  if (diffDays === 1) return `Yesterday · ${fmt}`;
  return fmt;
}
