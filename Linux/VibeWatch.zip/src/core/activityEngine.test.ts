import test from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_CATEGORIES,
  categorizeEvent,
  computeAnalytics,
  filterEventsInRange,
  formatAnchorDateLabel,
  formatDuration,
  getRangeBounds,
  parseCategoriesJson,
  recordHeartbeat,
  serializeCategoriesJson,
} from './activityEngine';
import { ANCHOR_TODAY, buildSeedActivityEvents } from './seedData';

test('heartbeat merge extends existing event within 5.0s pulsetime and splits otherwise', () => {
  const t0 = 1700000000;
  let state = recordHeartbeat([], {
    now: t0,
    app_binary: 'zen-bin',
    wm_class: 'zen',
    window_title: 'KDE Docs — Zen Browser',
    is_afk: false,
  });
  assert.equal(state.action, 'inserted');
  assert.equal(state.events.length, 1);

  state = recordHeartbeat(state.events, {
    now: t0 + 2.0,
    app_binary: 'zen-bin',
    wm_class: 'zen',
    window_title: 'KDE Docs — Zen Browser',
    is_afk: false,
  });
  assert.equal(state.action, 'merged');
  assert.equal(state.events.length, 1);
  assert.equal(state.events[0].end_ts, t0 + 2.0);

  // Gap > 5.0s must insert new row
  state = recordHeartbeat(state.events, {
    now: t0 + 9.0,
    app_binary: 'zen-bin',
    wm_class: 'zen',
    window_title: 'KDE Docs — Zen Browser',
    is_afk: false,
  });
  assert.equal(state.action, 'inserted');
  assert.equal(state.events.length, 2);

  // AFK transition within 5.0s must still insert new row
  state = recordHeartbeat(state.events, {
    now: t0 + 11.0,
    app_binary: 'zen-bin',
    wm_class: 'zen',
    window_title: 'KDE Docs — Zen Browser',
    is_afk: true,
  });
  assert.equal(state.action, 'inserted');
  assert.equal(state.events.length, 3);
  assert.equal(state.events[2].is_afk, true);
});

test('smart app grouping collapses dynamic window titles under one app_binary', () => {
  const all = buildSeedActivityEvents();
  const { startTs, endTs } = getRangeBounds(ANCHOR_TODAY, 'day');
  const todayEvents = filterEventsInRange(all, startTs, endTs);
  const snap = computeAnalytics(todayEvents, DEFAULT_CATEGORIES, false);

  const wt = snap.apps.find((a) => a.app_binary === 'War Thunder');
  assert.ok(wt, 'War Thunder should be grouped as a single top-level app');
  assert.equal(wt.category, 'Gaming');
  assert.equal(wt.titles.length, 3, 'War Thunder should expand into 3 distinct window titles');

  const zen = snap.apps.find((a) => a.app_binary === 'zen-bin');
  assert.ok(zen, 'zen-bin should be grouped as a single top-level app');
  assert.equal(zen.category, 'Browsing');
  assert.ok(zen.titles.length >= 3);
});

test('category filtering and Include AFK toggle update analytics accurately', () => {
  const all = buildSeedActivityEvents();
  const { startTs, endTs } = getRangeBounds(ANCHOR_TODAY, 'day');
  const todayEvents = filterEventsInRange(all, startTs, endTs);

  const withoutAfk = computeAnalytics(todayEvents, DEFAULT_CATEGORIES, false);
  const withAfk = computeAnalytics(todayEvents, DEFAULT_CATEGORIES, true);
  assert.ok(withAfk.afkSeconds > 0);
  assert.equal(withoutAfk.categories.some((c) => c.category === 'AFK'), false);
  assert.equal(withAfk.categories.some((c) => c.category === 'AFK'), true);
  assert.equal(withAfk.totalTrackedSeconds, withAfk.activeSeconds + withAfk.afkSeconds);

  const codingOnly = computeAnalytics(todayEvents, DEFAULT_CATEGORIES, false, 'Coding');
  assert.ok(codingOnly.apps.length > 0);
  assert.ok(codingOnly.apps.every((a) => a.category === 'Coding'));
});

test('categories.json parser validates syntax, colors, and regex patterns', () => {
  const ok = parseCategoriesJson(serializeCategoriesJson(DEFAULT_CATEGORIES));
  assert.equal(ok.error, undefined);
  assert.equal(ok.rules?.length, DEFAULT_CATEGORIES.length);

  const badJson = parseCategoriesJson('{broken');
  assert.ok(badJson.error);

  const badRegex = parseCategoriesJson(
    JSON.stringify({ categories: [{ name: 'Bad', color: '#88C0D0', pattern: '[unclosed' }] })
  );
  assert.ok(badRegex.error?.includes('invalid regex'));

  const customRules = [
    { name: 'Design', color: '#B48EAD', pattern: 'dolphin|figma' },
    ...DEFAULT_CATEGORIES,
  ];
  const matched = categorizeEvent(customRules, 'dolphin', 'org.kde.dolphin', '~/Downloads');
  assert.equal(matched.name, 'Design');
});

test('duration and anchor date formatting', () => {
  assert.equal(formatDuration(0), '0m');
  assert.equal(formatDuration(45), '< 1m');
  assert.equal(formatDuration(2700), '45m');
  assert.equal(formatDuration(3 * 3600 + 42 * 60), '3h 42m');

  assert.equal(formatAnchorDateLabel(ANCHOR_TODAY, ANCHOR_TODAY), 'Today · Sun, Nov 22');
  const yesterday = new Date(2026, 10, 21, 12, 0, 0);
  assert.equal(formatAnchorDateLabel(yesterday, ANCHOR_TODAY), 'Yesterday · Sat, Nov 21');
});
