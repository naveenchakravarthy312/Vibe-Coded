import React from 'react';
import { X } from 'lucide-react';

interface ShortcutsModalProps {
  open: boolean;
  onClose: () => void;
}

const SHORTCUT_ITEMS: Array<{ keys: string; description: string }> = [
  { keys: 'Left / Right', description: 'Step backward / forward by 1 day' },
  { keys: 'T', description: 'Jump back to Today' },
  { keys: '1 / 2 / 3', description: 'Switch between Day, 7 Days, and 30 Days' },
  { keys: 'A', description: 'Toggle Include AFK' },
  { keys: 'Ctrl + E', description: 'Open inline categories.json rule editor' },
  { keys: 'Ctrl + R / F5', description: 'Refresh data from SQLite' },
  { keys: 'Ctrl + Shift + D', description: 'Toggle Dark / Light theme' },
  { keys: 'Ctrl + = / - / 0', description: 'Dynamic zoom (8pt–48pt) / reset' },
  { keys: 'F11 / Ctrl+Shift+F', description: 'Toggle frameless window mode' },
  { keys: 'F1', description: 'Toggle this shortcuts overlay' },
  { keys: 'Escape', description: 'Dismiss active filter, overlay, or editor' },
  { keys: 'Ctrl + Q', description: 'Exit native PyQt6 dashboard' },
];

export function ShortcutsModal({ open, onClose }: ShortcutsModalProps) {
  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="shortcuts-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-lg rounded-lg border border-[var(--vw-border)] bg-[var(--vw-card)] p-5 shadow-2xl">
        <div className="flex items-center justify-between gap-4 pb-3 border-b border-[var(--vw-border)]">
          <h2 id="shortcuts-title" className="text-sm font-semibold text-[var(--vw-fg)]">
            Keyboard Shortcuts
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close keyboard shortcuts"
            className="rounded-md p-1.5 text-[var(--vw-meta)] hover:bg-[var(--vw-hover)] hover:text-[var(--vw-fg)] transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <dl className="mt-3 divide-y divide-[var(--vw-border)]/60">
          {SHORTCUT_ITEMS.map((item) => (
            <div key={item.keys} className="flex items-center justify-between gap-4 py-2 text-xs">
              <dt className="font-mono font-medium text-[var(--vw-accent)] whitespace-nowrap shrink-0">
                {item.keys}
              </dt>
              <dd className="text-right text-[var(--vw-fg)]">{item.description}</dd>
            </div>
          ))}
        </dl>

        <p className="mt-3 font-mono text-[11px] text-[var(--vw-meta)]">
          Press F1 or Escape to dismiss
        </p>
      </div>
    </div>
  );
}
