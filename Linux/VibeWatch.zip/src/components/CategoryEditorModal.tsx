import React, { useEffect, useState } from 'react';
import { X, RotateCcw } from 'lucide-react';
import {
  CategoryRule,
  DEFAULT_CATEGORIES,
  parseCategoriesJson,
  serializeCategoriesJson,
} from '../core/activityEngine';

interface CategoryEditorModalProps {
  open: boolean;
  rules: CategoryRule[];
  onSave: (nextRules: CategoryRule[]) => void;
  onClose: () => void;
}

export function CategoryEditorModal({
  open,
  rules,
  onSave,
  onClose,
}: CategoryEditorModalProps) {
  const [draft, setDraft] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setDraft(serializeCategoriesJson(rules));
      setError(null);
    }
  }, [open, rules]);

  if (!open) return null;

  const handleSave = () => {
    const parsed = parseCategoriesJson(draft);
    if (parsed.error || !parsed.rules) {
      setError(parsed.error || 'Invalid categories.json');
      return;
    }
    setError(null);
    onSave(parsed.rules);
    onClose();
  };

  const handleReset = () => {
    setDraft(serializeCategoriesJson(DEFAULT_CATEGORIES));
    setError(null);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="cat-editor-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-2xl rounded-lg border border-[var(--vw-border)] bg-[var(--vw-card)] p-5 shadow-2xl">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 id="cat-editor-title" className="text-sm font-semibold text-[var(--vw-fg)]">
              Edit categories.json
            </h2>
            <p className="mt-0.5 font-mono text-xs text-[var(--vw-meta)]">
              ~/.config/vibewatch/categories.json · live reload without daemon restart
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close categories editor"
            className="rounded-md p-1.5 text-[var(--vw-meta)] hover:bg-[var(--vw-hover)] hover:text-[var(--vw-fg)] transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <label htmlFor="categories-json-textarea" className="sr-only">
          Categories JSON configuration
        </label>
        <textarea
          id="categories-json-textarea"
          value={draft}
          onChange={(e) => {
            setDraft(e.target.value);
            if (error) setError(null);
          }}
          spellCheck={false}
          rows={16}
          className="mt-4 w-full rounded-md border border-[var(--vw-border)] bg-[var(--vw-canvas)] p-3 font-mono text-xs leading-relaxed text-[var(--vw-fg)] focus:border-[var(--vw-accent)] focus:outline-none"
        />

        {error && (
          <p role="alert" className="mt-2 font-mono text-xs text-red-400">
            {error}
          </p>
        )}

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleReset}
            className="inline-flex items-center gap-1.5 rounded-md border border-[var(--vw-border)] bg-[var(--vw-canvas)] px-3 py-1.5 text-xs font-medium text-[var(--vw-fg)] hover:bg-[var(--vw-hover)] transition-colors whitespace-nowrap shrink-0"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Reset Defaults
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-md border border-[var(--vw-border)] bg-[var(--vw-canvas)] px-3.5 py-1.5 text-xs font-medium text-[var(--vw-fg)] hover:bg-[var(--vw-hover)] transition-colors whitespace-nowrap shrink-0"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="rounded-md bg-[var(--vw-accent)] px-4 py-1.5 text-xs font-semibold text-white dark:text-[#141414] hover:opacity-90 transition-opacity whitespace-nowrap shrink-0"
            >
              Save &amp; Reload
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
