import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  TimelineSegment,
  formatClockTime,
  formatDuration,
} from '../core/activityEngine';

interface ActivityTimelineProps {
  segments: TimelineSegment[];
  dayStartTs: number;
  isDark: boolean;
  selectedCategory: string | null;
  onSelectCategory?: (category: string) => void;
}

interface SegmentGeometry {
  x0: number;
  x1: number;
  segment: TimelineSegment;
}

const DAY_SECONDS = 86400;
const TRACK_PAD_X = 4;
const TRACK_TOP = 8;
const TRACK_HEIGHT = 34;

export function ActivityTimeline({
  segments,
  dayStartTs,
  isDark,
  selectedCategory,
  onSelectCategory,
}: ActivityTimelineProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [canvasWidth, setCanvasWidth] = useState(960);
  const [hovered, setHovered] = useState<{
    segment: TimelineSegment;
    x: number;
  } | null>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const updateWidth = () => {
      const next = Math.max(280, Math.floor(el.clientWidth));
      setCanvasWidth(next);
    };
    updateWidth();
    const ro = new ResizeObserver(updateWidth);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const geometries = useMemo<SegmentGeometry[]>(() => {
    const trackW = Math.max(1, canvasWidth - TRACK_PAD_X * 2);
    const items: SegmentGeometry[] = [];
    for (const seg of segments) {
      const relStart = Math.max(0, Math.min(DAY_SECONDS, seg.start_ts - dayStartTs));
      const relEnd = Math.max(relStart, Math.min(DAY_SECONDS, seg.end_ts - dayStartTs));
      if (relEnd <= relStart) continue;
      const x0 = TRACK_PAD_X + (relStart / DAY_SECONDS) * trackW;
      const x1 = Math.max(x0 + 2, TRACK_PAD_X + (relEnd / DAY_SECONDS) * trackW);
      items.push({ x0, x1, segment: seg });
    }
    return items;
  }, [segments, dayStartTs, canvasWidth]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const cssHeight = 72;
    canvas.width = Math.floor(canvasWidth * dpr);
    canvas.height = Math.floor(cssHeight * dpr);
    canvas.style.width = `${canvasWidth}px`;
    canvas.style.height = `${cssHeight}px`;

    ctx.save();
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, canvasWidth, cssHeight);

    const trackW = Math.max(1, canvasWidth - TRACK_PAD_X * 2);
    const barBg = isDark ? '#242428' : '#e4e4e2';
    const borderCol = isDark ? '#2C2C30' : '#d4d4d0';
    const tickLabelCol = isDark ? '#8A8A8E' : '#666666';
    const afkGapCol = isDark ? '#1A1A1E' : '#d4d4d0';

    // Rounded track backdrop
    const drawRoundedRect = (x: number, y: number, w: number, h: number, r: number) => {
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.lineTo(x + w - r, y);
      ctx.quadraticCurveTo(x + w, y, x + w, y + r);
      ctx.lineTo(x + w, y + h - r);
      ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
      ctx.lineTo(x + r, y + h);
      ctx.quadraticCurveTo(x, y + h, x, y + h - r);
      ctx.lineTo(x, y + r);
      ctx.quadraticCurveTo(x, y, x + r, y);
      ctx.closePath();
    };

    ctx.save();
    drawRoundedRect(TRACK_PAD_X, TRACK_TOP, trackW, TRACK_HEIGHT, 4);
    ctx.fillStyle = barBg;
    ctx.fill();
    ctx.clip();

    // Subtle hourly vertical guides
    ctx.strokeStyle = isDark ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.04)';
    ctx.lineWidth = 1;
    for (let h = 1; h < 24; h++) {
      const gx = Math.round(TRACK_PAD_X + (h / 24) * trackW) + 0.5;
      ctx.beginPath();
      ctx.moveTo(gx, TRACK_TOP);
      ctx.lineTo(gx, TRACK_TOP + TRACK_HEIGHT);
      ctx.stroke();
    }

    // Draw color-coded activity blocks & AFK gaps
    for (const g of geometries) {
      const isHovered = hovered?.segment === g.segment;
      const isDimmed =
        selectedCategory !== null &&
        !g.segment.is_afk &&
        g.segment.category !== selectedCategory;

      ctx.globalAlpha = isDimmed ? 0.24 : 1.0;
      ctx.fillStyle = g.segment.is_afk ? afkGapCol : g.segment.color;
      ctx.fillRect(g.x0, TRACK_TOP, g.x1 - g.x0, TRACK_HEIGHT);

      if (g.segment.is_afk) {
        // Subtle diagonal hatch strictly clipped to the AFK segment bounds
        ctx.save();
        ctx.beginPath();
        ctx.rect(g.x0, TRACK_TOP, g.x1 - g.x0, TRACK_HEIGHT);
        ctx.clip();
        ctx.strokeStyle = isDark ? 'rgba(255,255,255,0.09)' : 'rgba(0,0,0,0.14)';
        ctx.lineWidth = 1;
        for (let sx = g.x0 - TRACK_HEIGHT; sx < g.x1; sx += 7) {
          ctx.beginPath();
          ctx.moveTo(sx, TRACK_TOP + TRACK_HEIGHT);
          ctx.lineTo(sx + TRACK_HEIGHT, TRACK_TOP);
          ctx.stroke();
        }
        ctx.restore();
      }

      if (isHovered) {
        ctx.globalAlpha = 1.0;
        ctx.strokeStyle = isDark ? '#E0E0E0' : '#1e1e1e';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(g.x0 + 0.75, TRACK_TOP + 0.75, Math.max(1, g.x1 - g.x0 - 1.5), TRACK_HEIGHT - 1.5);
      }
    }
    ctx.restore();

    // Track hairline border
    drawRoundedRect(TRACK_PAD_X + 0.5, TRACK_TOP + 0.5, trackW - 1, TRACK_HEIGHT - 1, 4);
    ctx.strokeStyle = borderCol;
    ctx.lineWidth = 1;
    ctx.stroke();

    // Hour ticks and labels (00:00 .. 24:00 every 3 hours; every 6h on narrow screens)
    const step = canvasWidth < 560 ? 6 : 3;
    ctx.font = '500 11px "JetBrains Mono", monospace';
    ctx.fillStyle = tickLabelCol;
    ctx.textBaseline = 'top';

    for (let hour = 0; hour <= 24; hour += step) {
      const x = TRACK_PAD_X + (hour / 24) * trackW;
      ctx.strokeStyle = borderCol;
      ctx.beginPath();
      ctx.moveTo(Math.round(x) + 0.5, TRACK_TOP + TRACK_HEIGHT + 2);
      ctx.lineTo(Math.round(x) + 0.5, TRACK_TOP + TRACK_HEIGHT + 7);
      ctx.stroke();

      const label = `${String(hour).padStart(2, '0')}:00`;
      const tw = ctx.measureText(label).width;
      const tx = Math.max(TRACK_PAD_X, Math.min(canvasWidth - TRACK_PAD_X - tw, x - tw / 2));
      ctx.fillText(label, tx, TRACK_TOP + TRACK_HEIGHT + 11);
    }

    ctx.restore();
  }, [geometries, canvasWidth, isDark, hovered, selectedCategory]);

  const handlePointerMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (y < TRACK_TOP || y > TRACK_TOP + TRACK_HEIGHT) {
      if (hovered) setHovered(null);
      return;
    }

    const hit = geometries.find((g) => x >= g.x0 && x <= g.x1);
    if (hit) {
      setHovered({ segment: hit.segment, x });
    } else if (hovered) {
      setHovered(null);
    }
  };

  const handleClick = () => {
    if (hovered && !hovered.segment.is_afk && onSelectCategory) {
      onSelectCategory(hovered.segment.category);
    }
  };

  return (
    <div ref={containerRef} className="relative w-full select-none">
      <canvas
        ref={canvasRef}
        data-testid="activity-timeline-canvas"
        aria-label="24-hour horizontal activity timeline from 00:00 to 24:00"
        onMouseMove={handlePointerMove}
        onMouseLeave={() => setHovered(null)}
        onClick={handleClick}
        className={`block w-full ${hovered && !hovered.segment.is_afk ? 'cursor-pointer' : 'cursor-default'}`}
      />

      {hovered && (
        <div
          role="tooltip"
          style={{
            left: `${Math.max(12, Math.min(canvasWidth - 292, hovered.x - 140))}px`,
          }}
          className="pointer-events-none absolute -top-2 -translate-y-full z-20 w-[280px] rounded-md border border-[var(--vw-border)] bg-[var(--vw-card)] px-3 py-2 text-xs shadow-lg"
        >
          <div className="flex items-center justify-between gap-2 font-mono text-[11px] text-[var(--vw-meta)]">
            <span>
              {formatClockTime(hovered.segment.start_ts)}–{formatClockTime(hovered.segment.end_ts)}
            </span>
            <span>{formatDuration(hovered.segment.end_ts - hovered.segment.start_ts)}</span>
          </div>
          <div className="mt-1 flex items-center gap-2 font-medium text-[var(--vw-fg)]">
            <span
              className="inline-block h-2 w-2 shrink-0 rounded-xs"
              style={{
                backgroundColor: hovered.segment.is_afk
                  ? isDark
                    ? '#585858'
                    : '#888888'
                  : hovered.segment.color,
              }}
            />
            <span className="truncate">{hovered.segment.app_binary}</span>
            <span className="text-[var(--vw-meta)]">·</span>
            <span className="shrink-0 text-[var(--vw-meta)]">{hovered.segment.category}</span>
          </div>
          <div className="mt-0.5 truncate text-[11px] text-[var(--vw-meta)]">
            {hovered.segment.window_title}
          </div>
        </div>
      )}
    </div>
  );
}
