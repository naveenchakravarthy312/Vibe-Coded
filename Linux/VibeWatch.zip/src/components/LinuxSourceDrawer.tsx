import React, { useState } from 'react';
import { Check, Copy, Download, X } from 'lucide-react';
import { LINUX_SOURCE_FILES } from '../data/linuxFiles';

interface LinuxSourceDrawerProps {
  open: boolean;
  onClose: () => void;
}

export function LinuxSourceDrawer({ open, onClose }: LinuxSourceDrawerProps) {
  const [activeFileName, setActiveFileName] = useState(LINUX_SOURCE_FILES[0].name);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!open) return null;

  const activeFile =
    LINUX_SOURCE_FILES.find((f) => f.name === activeFileName) ?? LINUX_SOURCE_FILES[0];

  const handleCopy = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      window.setTimeout(() => setCopiedKey(null), 1800);
    } catch {
      // Fallback copy unavailable in restricted frames
    }
  };

  const handleDownloadFile = () => {
    const blob = new Blob([activeFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeFile.name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const installCmd = 'cd Linux/Activity-Tracker && python3 setup.py';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="linux-drawer-title"
      className="fixed inset-0 z-50 flex justify-end bg-black/60"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="flex h-full w-full max-w-4xl flex-col border-l border-[var(--vw-border)] bg-[var(--vw-card)] shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 border-b border-[var(--vw-border)] px-5 py-4">
          <div className="min-w-0">
            <h2 id="linux-drawer-title" className="text-sm font-semibold text-[var(--vw-fg)]">
              Native KDE Plasma 6 (Wayland) Package
            </h2>
            <p className="mt-0.5 truncate font-mono text-xs text-[var(--vw-meta)]">
              Linux/Activity-Tracker/ · Python 3.11 + PyQt6 + dbus-next + SQLite WAL
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Linux source viewer"
            className="rounded-md p-1.5 text-[var(--vw-meta)] hover:bg-[var(--vw-hover)] hover:text-[var(--vw-fg)] transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* One-line install strip */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--vw-border)] bg-[var(--vw-canvas)] px-5 py-3">
          <div className="min-w-0">
            <span className="text-xs text-[var(--vw-meta)]">Install .venv, systemd --user daemon &amp; KRunner launcher:</span>
            <code className="mt-0.5 block font-mono text-xs text-[var(--vw-accent)]">
              {installCmd}
            </code>
          </div>
          <button
            type="button"
            onClick={() => handleCopy('install', installCmd)}
            className="inline-flex items-center gap-1.5 rounded-md border border-[var(--vw-border)] bg-[var(--vw-card)] px-3 py-1.5 text-xs font-medium text-[var(--vw-fg)] hover:bg-[var(--vw-hover)] transition-colors whitespace-nowrap shrink-0"
          >
            {copiedKey === 'install' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
            {copiedKey === 'install' ? 'Copied' : 'Copy Command'}
          </button>
        </div>

        {/* File selector tabs */}
        <div className="flex items-center gap-1 overflow-x-auto border-b border-[var(--vw-border)] px-5 py-2">
          {LINUX_SOURCE_FILES.map((file) => {
            const active = file.name === activeFile.name;
            return (
              <button
                key={file.name}
                type="button"
                aria-pressed={active}
                onClick={() => setActiveFileName(file.name)}
                className={`rounded-md px-2.5 py-1.5 font-mono text-xs whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-[var(--vw-accent)] font-semibold text-white dark:text-[#141414]'
                    : 'text-[var(--vw-meta)] hover:bg-[var(--vw-hover)] hover:text-[var(--vw-fg)]'
                }`}
              >
                {file.name}
              </button>
            );
          })}
        </div>

        {/* Active file metadata & actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--vw-border)] px-5 py-2.5">
          <div className="min-w-0 text-xs">
            <span className="font-mono font-medium text-[var(--vw-fg)]">{activeFile.path}</span>
            <span className="mx-2 text-[var(--vw-meta)]">·</span>
            <span className="text-[var(--vw-meta)]">{activeFile.role}</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => handleCopy(activeFile.name, activeFile.content)}
              className="inline-flex items-center gap-1.5 rounded-md border border-[var(--vw-border)] bg-[var(--vw-canvas)] px-3 py-1.5 text-xs font-medium text-[var(--vw-fg)] hover:bg-[var(--vw-hover)] transition-colors whitespace-nowrap shrink-0"
            >
              {copiedKey === activeFile.name ? (
                <Check className="h-3.5 w-3.5" />
              ) : (
                <Copy className="h-3.5 w-3.5" />
              )}
              {copiedKey === activeFile.name ? 'Copied' : 'Copy File'}
            </button>
            <button
              type="button"
              onClick={handleDownloadFile}
              className="inline-flex items-center gap-1.5 rounded-md border border-[var(--vw-border)] bg-[var(--vw-canvas)] px-3 py-1.5 text-xs font-medium text-[var(--vw-fg)] hover:bg-[var(--vw-hover)] transition-colors whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              Download
            </button>
          </div>
        </div>

        {/* File contents */}
        <div className="flex-1 overflow-auto bg-[var(--vw-canvas)] p-5">
          <pre className="font-mono text-xs leading-relaxed text-[var(--vw-fg)] whitespace-pre">
            <code>{activeFile.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
}
