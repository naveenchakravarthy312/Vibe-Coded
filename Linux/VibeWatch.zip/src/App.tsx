import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Code2,
  Moon,
  SlidersHorizontal,
  Sun,
} from 'lucide-react';
import {
  CategoryRule,
  DEFAULT_CATEGORIES,
  RangeMode,
  computeAnalytics,
  filterEventsInRange,
  formatAnchorDateLabel,
  formatDuration,
  getRangeBounds,
} from './core/activityEngine';
import { ANCHOR_TODAY, buildSeedActivityEvents } from './core/seedData';
import { ActivityTimeline } from './components/ActivityTimeline';
import { CategoryEditorModal } from './components/CategoryEditorModal';
import { ShortcutsModal } from './components/ShortcutsModal';
import { LinuxSourceDrawer } from './components/LinuxSourceDrawer';

const CATEGORIES_STORAGE_KEY = 'vibewatch_categories_v1';
const THEME_STORAGE_KEY = 'vibewatch_theme_v1';

function loadInitialCategories(): CategoryRule[] {
  try {
    const raw = window.localStorage.getItem(CATEGORIES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch {
    // Ignore storage errors
  }
  return DEFAULT_CATEGORIES;
}

function loadInitialDark(): boolean {
  try {
    const saved = window.localStorage.getItem(THEME_STORAGE_KEY);
    if (saved === 'light') return false;
    if (saved === 'dark') return true;
  } catch {
    // Default Dark Mode
  }
  return true;
}

export default function App() {
  const [events] = useState(() => buildSeedActivityEvents());
  const [categories, setCategories] = useState<CategoryRule[]>(loadInitialCategories);
  const [isDark, setIsDark] = useState<boolean>(loadInitialDark);
  const [anchorDate, setAnchorDate] = useState<Date>(() => new Date(ANCHOR_TODAY));
  const [rangeMode, setRangeMode] = useState<RangeMode>('day');
  const [includeAfk, setIncludeAfk] = useState<boolean>(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [expandedApps, setExpandedApps] = useState<Set<string>>(() => new Set());
  const [fontPt, setFontPt] = useState<number>(11);
  const [frameless, setFrameless] = useState<boolean>(false);
  const [refreshTick, setRefreshTick] = useState<number>(0);

  const [editorOpen, setEditorOpen] = useState<boolean>(false);
  const [shortcutsOpen, setShortcutsOpen] = useState<boolean>(false);
  const [linuxDrawerOpen, setLinuxDrawerOpen] = useState<boolean>(false);

  // Sync Tailwind .dark class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      window.localStorage.setItem(THEME_STORAGE_KEY, isDark ? 'dark' : 'light');
    } catch {
      // Ignore storage failures
    }
  }, [isDark]);

  // Persist custom categories.json edits
  const handleSaveCategories = useCallback((nextRules: CategoryRule[]) => {
    setCategories(nextRules);
    setSelectedCategory((prev) =>
      prev && nextRules.some((r) => r.name === prev) ? prev : null
    );
    try {
      window.localStorage.setItem(CATEGORIES_STORAGE_KEY, JSON.stringify(nextRules));
    } catch {
      // Ignore storage failures
    }
  }, []);

  const stepDay = useCallback((delta: number) => {
    setAnchorDate((prev) => {
      const next = new Date(prev);
      next.setDate(next.getDate() + delta);
      // Prevent stepping beyond Anchor Today
      if (next.getTime() > ANCHOR_TODAY.getTime()) {
        return new Date(ANCHOR_TODAY);
      }
      return next;
    });
  }, []);

  const jumpToday = useCallback(() => {
    setAnchorDate(new Date(ANCHOR_TODAY));
  }, []);

  const toggleCategoryFilter = useCallback((category: string) => {
    setSelectedCategory((prev) => (prev === category ? null : category));
  }, []);

  const toggleAppExpand = useCallback((appBinary: string) => {
    setExpandedApps((prev) => {
      const next = new Set(prev);
      if (next.has(appBinary)) {
        next.delete(appBinary);
      } else {
        next.add(appBinary);
      }
      return next;
    });
  }, []);

  // Global keyboard shortcuts matching dashboard.py
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const inEditable =
        target &&
        (target.tagName === 'TEXTAREA' ||
          target.tagName === 'INPUT' ||
          target.isContentEditable);

      // Escape works everywhere
      if (e.key === 'Escape') {
        e.preventDefault();
        if (editorOpen) {
          setEditorOpen(false);
        } else if (shortcutsOpen) {
          setShortcutsOpen(false);
        } else if (linuxDrawerOpen) {
          setLinuxDrawerOpen(false);
        } else if (selectedCategory !== null) {
          setSelectedCategory(null);
        } else if (expandedApps.size > 0) {
          setExpandedApps(new Set());
        }
        return;
      }

      if (e.key === 'F1') {
        e.preventDefault();
        setShortcutsOpen((prev) => !prev);
        return;
      }

      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'd') {
        e.preventDefault();
        setIsDark((prev) => !prev);
        return;
      }

      if (e.ctrlKey && !e.shiftKey && e.key.toLowerCase() === 'e') {
        e.preventDefault();
        setEditorOpen((prev) => !prev);
        return;
      }

      if ((e.ctrlKey && e.key.toLowerCase() === 'r') || e.key === 'F5') {
        e.preventDefault();
        setRefreshTick((t) => t + 1);
        return;
      }

      if (e.key === 'F11' || (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'f')) {
        e.preventDefault();
        setFrameless((prev) => !prev);
        return;
      }

      if (e.ctrlKey && (e.key === '=' || e.key === '+')) {
        e.preventDefault();
        setFontPt((pt) => Math.min(48, pt + 1));
        return;
      }

      if (e.ctrlKey && e.key === '-') {
        e.preventDefault();
        setFontPt((pt) => Math.max(8, pt - 1));
        return;
      }

      if (e.ctrlKey && e.key === '0') {
        e.preventDefault();
        setFontPt(11);
        return;
      }

      if (inEditable || editorOpen || shortcutsOpen || linuxDrawerOpen) return;

      if (!e.ctrlKey && !e.metaKey && !e.altKey) {
        if (e.key === 'ArrowLeft') {
          e.preventDefault();
          stepDay(-1);
        } else if (e.key === 'ArrowRight') {
          e.preventDefault();
          stepDay(1);
        } else if (e.key.toLowerCase() === 't') {
          e.preventDefault();
          jumpToday();
        } else if (e.key === '1') {
          e.preventDefault();
          setRangeMode('day');
        } else if (e.key === '2') {
          e.preventDefault();
          setRangeMode('7d');
        } else if (e.key === '3') {
          e.preventDefault();
          setRangeMode('30d');
        } else if (e.key.toLowerCase() === 'a') {
          e.preventDefault();
          setIncludeAfk((prev) => !prev);
        }
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [editorOpen, shortcutsOpen, linuxDrawerOpen, selectedCategory, expandedApps, stepDay, jumpToday]);

  // Compute filtered analytics for current date & range
  const { analytics, dayTimelineSegments, dayStartTs } = useMemo(() => {
    void refreshTick;
    const { startTs, endTs } = getRangeBounds(anchorDate, rangeMode);
    const rangedEvents = filterEventsInRange(events, startTs, endTs);
    const snap = computeAnalytics(rangedEvents, categories, includeAfk, selectedCategory);

    const dayBounds = getRangeBounds(anchorDate, 'day');
    const dayEvents =
      rangeMode === 'day'
        ? rangedEvents
        : filterEventsInRange(events, dayBounds.startTs, dayBounds.endTs);
    const daySnap =
      rangeMode === 'day'
        ? snap
        : computeAnalytics(dayEvents, categories, true, null);

    return {
      analytics: snap,
      dayTimelineSegments: daySnap.timeline,
      dayStartTs: dayBounds.startTs,
    };
  }, [events, anchorDate, rangeMode, categories, includeAfk, selectedCategory, refreshTick]);

  const dateLabel = formatAnchorDateLabel(anchorDate, ANCHOR_TODAY);
  const isAtToday =
    anchorDate.getFullYear() === ANCHOR_TODAY.getFullYear() &&
    anchorDate.getMonth() === ANCHOR_TODAY.getMonth() &&
    anchorDate.getDate() === ANCHOR_TODAY.getDate();

  const zoomScale = fontPt / 11;

  return (
    <div
      data-theme={isDark ? 'dark' : 'light'}
      data-range={rangeMode}
      data-frameless={frameless ? 'true' : 'false'}
      style={{ fontSize: `${Math.round(14 * zoomScale)}px` }}
      className={`min-h-screen bg-[var(--vw-canvas)] text-[var(--vw-fg)] ${
        frameless ? 'p-3' : 'p-4 sm:p-6'
      }`}
    >
      <main className="mx-auto flex max-w-[1392px] flex-col gap-4">
        {/* 1. Zero-Chrome Top Control Strip */}
        <header className="flex flex-wrap items-center justify-between gap-3">
          {/* Date navigation */}
          <div className="flex items-center gap-2">
            <h1 className="mr-2 text-sm font-semibold tracking-tight text-[var(--vw-fg)] whitespace-nowrap shrink-0">
              VibeWatch
            </h1>
            <span aria-hidden="true" className="text-[var(--vw-border)]">
              /
            </span>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => stepDay(-1)}
                aria-label="Previous day"
                title="Previous day (Left Arrow)"
                className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-[var(--vw-border)] bg-[var(--vw-card)] text-[var(--vw-fg)] hover:bg-[var(--vw-hover)] focus-visible:outline-2 focus-visible:outline-[var(--vw-accent)]"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={jumpToday}
                title="Jump to Today (T)"
                className="h-8 rounded-md px-3 text-sm font-semibold tracking-tight text-[var(--vw-fg)] hover:bg-[var(--vw-hover)] whitespace-nowrap shrink-0"
              >
                {dateLabel}
              </button>
              <button
                type="button"
                onClick={() => stepDay(1)}
                disabled={isAtToday}
                aria-label="Next day"
                title="Next day (Right Arrow)"
                className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-[var(--vw-border)] bg-[var(--vw-card)] text-[var(--vw-fg)] hover:bg-[var(--vw-hover)] disabled:opacity-35 disabled:pointer-events-none focus-visible:outline-2 focus-visible:outline-[var(--vw-accent)]"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Right functional controls */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Segmented Range Selector */}
            <div
              role="group"
              aria-label="Time range"
              className="inline-flex items-center rounded-md border border-[var(--vw-border)] bg-[var(--vw-card)] p-0.5"
            >
              {(
                [
                  { id: 'day', label: 'Day' },
                  { id: '7d', label: '7 Days' },
                  { id: '30d', label: '30 Days' },
                ] as const
              ).map((tab) => {
                const active = rangeMode === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    aria-pressed={active}
                    onClick={() => setRangeMode(tab.id)}
                    className={`rounded-sm px-2.5 py-1 text-xs font-medium whitespace-nowrap shrink-0 ${
                      active
                        ? 'bg-[var(--vw-accent)] font-semibold text-white dark:text-[#141414]'
                        : 'text-[var(--vw-meta)] hover:text-[var(--vw-fg)]'
                    }`}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* Include AFK Toggle */}
            <button
              type="button"
              aria-pressed={includeAfk}
              onClick={() => setIncludeAfk((prev) => !prev)}
              title="Toggle Include AFK (A)"
              className={`h-8 rounded-md border px-3 text-xs font-medium whitespace-nowrap shrink-0 ${
                includeAfk
                  ? 'border-[var(--vw-accent)] bg-[var(--vw-accent)] font-semibold text-white dark:text-[#141414]'
                  : 'border-[var(--vw-border)] bg-[var(--vw-card)] text-[var(--vw-fg)] hover:bg-[var(--vw-hover)]'
              }`}
            >
              Include AFK
            </button>

            {/* Edit Categories */}
            <button
              type="button"
              onClick={() => setEditorOpen(true)}
              title="Edit categories.json (Ctrl+E)"
              className="inline-flex h-8 items-center gap-1.5 rounded-md border border-[var(--vw-border)] bg-[var(--vw-card)] px-3 text-xs font-medium text-[var(--vw-fg)] hover:bg-[var(--vw-hover)] whitespace-nowrap shrink-0"
            >
              <SlidersHorizontal className="h-3.5 w-3.5 text-[var(--vw-meta)]" />
              Edit Categories
            </button>

            {/* Theme Toggle */}
            <button
              type="button"
              onClick={() => setIsDark((prev) => !prev)}
              aria-label={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              title="Toggle Dark / Light Mode (Ctrl+Shift+D)"
              className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-[var(--vw-border)] bg-[var(--vw-card)] text-[var(--vw-fg)] hover:bg-[var(--vw-hover)] shrink-0"
            >
              {isDark ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
            </button>

            {/* Native Linux Source & Setup Drawer */}
            <button
              type="button"
              onClick={() => setLinuxDrawerOpen(true)}
              title="Inspect Linux/Activity-Tracker Python & PyQt6 files"
              className="inline-flex h-8 items-center gap-1.5 rounded-md border border-[var(--vw-border)] bg-[var(--vw-card)] px-3 text-xs font-medium text-[var(--vw-fg)] hover:bg-[var(--vw-hover)] whitespace-nowrap shrink-0"
            >
              <Code2 className="h-3.5 w-3.5 text-[var(--vw-accent)]" />
              Linux Files
            </button>
          </div>
        </header>

        {/* Summary KPI Strip (4 columns, crisp hairline grid on both mobile 2x2 and desktop 4x1) */}
        <section
          aria-label="Summary metrics"
          className="grid grid-cols-2 lg:grid-cols-4 gap-px overflow-hidden rounded-lg border border-[var(--vw-border)] bg-[var(--vw-border)]"
        >
          <div className="bg-[var(--vw-card)] px-4 py-3.5">
            <div className="text-xs text-[var(--vw-meta)]">Active Time</div>
            <div
              data-testid="kpi-active-time"
              className="mt-1 font-mono text-xl font-semibold tracking-tight text-[var(--vw-accent)]"
            >
              {formatDuration(analytics.activeSeconds)}
            </div>
          </div>

          <div className="bg-[var(--vw-card)] px-4 py-3.5">
            <div className="text-xs text-[var(--vw-meta)]">Top Category</div>
            <div
              data-testid="kpi-top-category"
              className="mt-1 flex items-center gap-2 text-xl font-semibold tracking-tight text-[var(--vw-fg)]"
            >
              <span
                aria-hidden="true"
                className="inline-block h-2.5 w-2.5 shrink-0 rounded-xs"
                style={{ backgroundColor: analytics.topCategoryColor }}
              />
              <span className="truncate">{analytics.topCategory}</span>
            </div>
          </div>

          <div className="bg-[var(--vw-card)] px-4 py-3.5">
            <div className="text-xs text-[var(--vw-meta)]">Top App</div>
            <div
              data-testid="kpi-top-app"
              className="mt-1 truncate font-mono text-xl font-semibold tracking-tight text-[var(--vw-fg)]"
            >
              {analytics.topApp}
            </div>
          </div>

          <div className="bg-[var(--vw-card)] px-4 py-3.5">
            <div className="text-xs text-[var(--vw-meta)]">AFK Time</div>
            <div
              data-testid="kpi-afk-time"
              className="mt-1 font-mono text-xl font-semibold tracking-tight text-[var(--vw-fg)]"
            >
              {formatDuration(analytics.afkSeconds)}
            </div>
          </div>
        </section>

        {/* 2. 24-Hour Activity Timeline */}
        <section
          aria-label="24-Hour Activity Timeline"
          className="rounded-lg border border-[var(--vw-border)] bg-[var(--vw-card)] px-4 pt-3.5 pb-2.5"
        >
          <div className="mb-2 flex items-center justify-between gap-2">
            <h2 className="text-xs font-semibold text-[var(--vw-fg)] whitespace-nowrap">
              24-Hour Activity Timeline
            </h2>
            <div className="flex items-center gap-2 font-mono text-[11px] text-[var(--vw-meta)] whitespace-nowrap">
              <span>{dateLabel}</span>
              <span aria-hidden="true" className="hidden sm:inline">
                ·
              </span>
              <span className="hidden sm:inline">Hover blocks for window details</span>
            </div>
          </div>
          <ActivityTimeline
            segments={dayTimelineSegments}
            dayStartTs={dayStartTs}
            isDark={isDark}
            selectedCategory={selectedCategory}
            onSelectCategory={toggleCategoryFilter}
          />
        </section>

        {/* 3. Two-Column Breakdown Grid */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
          {/* Left Card: Top Categories */}
          <div className="lg:col-span-5 flex flex-col rounded-lg border border-[var(--vw-border)] bg-[var(--vw-card)] p-4">
            <div className="mb-3 flex items-center justify-between gap-2">
              <h2 className="text-xs font-semibold text-[var(--vw-fg)]">Top Categories</h2>
              <span className="font-mono text-[11px] text-[var(--vw-meta)]">
                {selectedCategory ? `Filtered: ${selectedCategory}` : 'Click to filter'}
              </span>
            </div>

            {analytics.categories.length === 0 ? (
              <div className="py-10 text-center text-xs text-[var(--vw-meta)]">
                No activity recorded for this range.
              </div>
            ) : (
              <div className="flex flex-col gap-1.5" role="list" aria-label="Category breakdown">
                {analytics.categories.map((cat) => {
                  const isSelected = selectedCategory === cat.category;
                  return (
                    <button
                      key={cat.category}
                      type="button"
                      aria-pressed={isSelected}
                      onClick={() => toggleCategoryFilter(cat.category)}
                      className={`group w-full rounded-md border px-3 py-2 text-left transition-colors focus-visible:outline-2 focus-visible:outline-[var(--vw-accent)] ${
                        isSelected
                          ? 'border-[var(--vw-accent)] bg-[var(--vw-hover)]'
                          : 'border-transparent hover:bg-[var(--vw-hover)]'
                      }`}
                    >
                      <div className="flex items-baseline justify-between gap-3">
                        <span className="truncate text-xs font-medium text-[var(--vw-fg)]">
                          {cat.category}
                        </span>
                        <span className="font-mono text-xs text-[var(--vw-meta)] whitespace-nowrap shrink-0">
                          <span className="font-medium text-[var(--vw-fg)]">
                            {formatDuration(cat.duration)}
                          </span>
                          <span className="ml-2 inline-block w-11 text-right">
                            {cat.percentage.toFixed(1)}%
                          </span>
                        </span>
                      </div>
                      <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-xs bg-[var(--vw-bar-bg)]">
                        <div
                          className="h-full rounded-xs transition-[width] duration-200"
                          style={{
                            width: `${Math.max(2, Math.min(100, cat.percentage))}%`,
                            backgroundColor: cat.color,
                          }}
                        />
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right Card: Top Applications (Expandable inline window_title list) */}
          <div className="lg:col-span-7 flex flex-col rounded-lg border border-[var(--vw-border)] bg-[var(--vw-card)] p-4">
            <div className="mb-3 flex items-center justify-between gap-2">
              <h2 className="text-xs font-semibold text-[var(--vw-fg)]">
                Top Applications
                {selectedCategory && (
                  <span className="ml-2 font-normal text-[var(--vw-meta)]">
                    · {selectedCategory}
                  </span>
                )}
              </h2>
              {selectedCategory ? (
                <button
                  type="button"
                  onClick={() => setSelectedCategory(null)}
                  className="rounded-sm px-2 py-0.5 font-mono text-[11px] text-[var(--vw-accent)] hover:bg-[var(--vw-hover)] transition-colors whitespace-nowrap shrink-0"
                >
                  Clear Filter (Esc)
                </button>
              ) : (
                <span className="font-mono text-[11px] text-[var(--vw-meta)]">
                  Click row to expand window titles
                </span>
              )}
            </div>

            {analytics.apps.length === 0 ? (
              <div className="py-10 text-center text-xs text-[var(--vw-meta)]">
                No applications match the current filter.
              </div>
            ) : (
              <div className="flex flex-col gap-1.5" data-testid="top-applications-list">
                {analytics.apps.map((app) => {
                  const isExpanded = expandedApps.has(app.app_binary);
                  return (
                    <div key={app.app_binary} className="rounded-md">
                      <button
                        type="button"
                        aria-expanded={isExpanded}
                        onClick={() => toggleAppExpand(app.app_binary)}
                        className="w-full rounded-md px-3 py-2 text-left hover:bg-[var(--vw-hover)] transition-colors focus-visible:outline-2 focus-visible:outline-[var(--vw-accent)]"
                      >
                        <div className="flex items-center justify-between gap-3">
                          <div className="flex min-w-0 items-center gap-2">
                            {isExpanded ? (
                              <ChevronDown className="h-3.5 w-3.5 shrink-0 text-[var(--vw-meta)]" />
                            ) : (
                              <ChevronRight className="h-3.5 w-3.5 shrink-0 text-[var(--vw-meta)]" />
                            )}
                            <span className="truncate font-mono text-xs font-medium text-[var(--vw-fg)]">
                              {app.app_binary}
                            </span>
                            <span className="hidden sm:inline text-[11px] text-[var(--vw-meta)] whitespace-nowrap shrink-0">
                              · {app.category}
                            </span>
                          </div>
                          <span className="font-mono text-xs text-[var(--vw-meta)] whitespace-nowrap shrink-0">
                            <span className="font-medium text-[var(--vw-fg)]">
                              {formatDuration(app.duration)}
                            </span>
                            <span className="ml-2 inline-block w-11 text-right">
                              {app.percentage.toFixed(1)}%
                            </span>
                          </span>
                        </div>

                        <div className="mt-1.5 ml-5 h-1.5 overflow-hidden rounded-xs bg-[var(--vw-bar-bg)]">
                          <div
                            className="h-full rounded-xs transition-[width] duration-200"
                            style={{
                              width: `${Math.max(2, Math.min(100, app.percentage))}%`,
                              backgroundColor: app.color,
                            }}
                          />
                        </div>
                      </button>

                      {/* Expanded inline window_title breakdown */}
                      {isExpanded && app.titles.length > 0 && (
                        <div className="mx-3 mb-2 mt-1 rounded-md bg-[var(--vw-canvas)] px-3 py-2 divide-y divide-[var(--vw-border)]/60">
                          {app.titles.map((entry) => (
                            <div
                              key={entry.window_title}
                              className="flex items-baseline justify-between gap-4 py-1.5 first:pt-0.5 last:pb-0.5 text-[11px]"
                            >
                              <span className="truncate text-[var(--vw-fg)]/90">
                                {entry.window_title}
                              </span>
                              <span className="font-mono text-[var(--vw-meta)] whitespace-nowrap shrink-0">
                                {formatDuration(entry.duration)} · {entry.percentage.toFixed(0)}%
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </section>

        {/* 4. Whisper-Quiet Status Anchor (Bottom-Right in #585858 / #888888) */}
        <footer className="flex flex-wrap items-center justify-end gap-x-2 gap-y-1 pt-1 font-mono text-[11px] text-[var(--vw-meta-quiet)]">
          <span>daemon: running</span>
          <span aria-hidden="true">·</span>
          <span>active: konsole</span>
          {fontPt !== 11 && (
            <>
              <span aria-hidden="true">·</span>
              <button
                type="button"
                onClick={() => setFontPt(11)}
                className="hover:text-[var(--vw-fg)] transition-colors"
              >
                zoom: {fontPt}pt
              </button>
            </>
          )}
          <span aria-hidden="true">·</span>
          <button
            type="button"
            onClick={() => setShortcutsOpen(true)}
            className="hover:text-[var(--vw-fg)] transition-colors"
          >
            F1 shortcuts
          </button>
        </footer>
      </main>

      <CategoryEditorModal
        open={editorOpen}
        rules={categories}
        onSave={handleSaveCategories}
        onClose={() => setEditorOpen(false)}
      />

      <ShortcutsModal
        open={shortcutsOpen}
        onClose={() => setShortcutsOpen(false)}
      />

      <LinuxSourceDrawer
        open={linuxDrawerOpen}
        onClose={() => setLinuxDrawerOpen(false)}
      />
    </div>
  );
}
