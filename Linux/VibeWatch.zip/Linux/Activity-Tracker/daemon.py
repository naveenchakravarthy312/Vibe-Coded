#!/usr/bin/env python3
"""
VibeWatch Headless Background Daemon (`daemon.py`)
Tailored for KDE Plasma 6 (Wayland) with a 3-tier Linux active-window collector,
org.freedesktop.ScreenSaver AFK/lock detection, and heartbeat-merged SQLite WAL writes.

Usage:
  python daemon.py              # Run headless 2.0s watcher loop
  python daemon.py --once       # Perform a single poll and print JSON
  python daemon.py --install    # Provision .venv, systemd --user service, and .desktop launcher
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

from vibewatch_core import (
    AFK_THRESHOLD_MS,
    DEFAULT_DB_PATH,
    HEARTBEAT_PULSETIME_SECONDS,
    POLL_INTERVAL_SECONDS,
    ActivityDatabase,
    CategoryEngine,
    ensure_venv,
    resolve_pid_binary,
    write_daemon_status,
)

# Self-heal into local .venv before importing optional third-party packages
ensure_venv(Path(__file__))

try:
    from dbus_next.aio import MessageBus  # type: ignore
    from dbus_next.service import ServiceInterface, method  # type: ignore
    HAS_DBUS_NEXT = True
except ImportError:
    MessageBus = None  # type: ignore
    ServiceInterface = object  # type: ignore
    HAS_DBUS_NEXT = False

    def method():  # type: ignore
        def _decorator(fn):
            return fn
        return _decorator


DBUS_SERVICE_NAME = "com.naveen.VibeWatch.Receiver"
DBUS_OBJECT_PATH = "/Receiver"
DBUS_INTERFACE_NAME = "com.naveen.VibeWatch.Receiver"

# Persistent KDE Plasma 6 KWin JavaScript bridge:
# Inspects `workspace.activeWindow` (caption, resourceClass, pid) on focus changes,
# caption updates, and a lightweight 2000ms timer, pushing snapshots to VibeWatch via callDBus.
KWIN_SCRIPT_TEMPLATE = """\
(function () {
    function pushActiveWindow(win) {
        var w = win || workspace.activeWindow;
        if (!w) {
            callDBus(
                "com.naveen.VibeWatch.Receiver",
                "/Receiver",
                "com.naveen.VibeWatch.Receiver",
                "ReportActiveWindow",
                "",
                "",
                0
            );
            return;
        }
        var caption = w.caption ? String(w.caption) : "";
        var resClass = w.resourceClass ? String(w.resourceClass) : "";
        var pid = typeof w.pid === "number" ? w.pid : 0;
        callDBus(
            "com.naveen.VibeWatch.Receiver",
            "/Receiver",
            "com.naveen.VibeWatch.Receiver",
            "ReportActiveWindow",
            caption,
            resClass,
            pid
        );
    }

    if (workspace.windowActivated) {
        workspace.windowActivated.connect(function (win) {
            pushActiveWindow(win);
            if (win && win.captionChanged) {
                try {
                    win.captionChanged.connect(function () {
                        if (workspace.activeWindow === win) {
                            pushActiveWindow(win);
                        }
                    });
                } catch (e) {}
            }
        });
    }

    // Immediate snapshot on script start
    pushActiveWindow(workspace.activeWindow);
})();
"""

# One-shot KWin query script executed on demand when no focus event arrived recently
KWIN_ONESHOT_SCRIPT = """\
(function () {
    var w = workspace.activeWindow;
    var caption = (w && w.caption) ? String(w.caption) : "";
    var resClass = (w && w.resourceClass) ? String(w.resourceClass) : "";
    var pid = (w && typeof w.pid === "number") ? w.pid : 0;
    callDBus(
        "com.naveen.VibeWatch.Receiver",
        "/Receiver",
        "com.naveen.VibeWatch.Receiver",
        "ReportActiveWindow",
        caption,
        resClass,
        pid
    );
})();
"""


@dataclass
class ActiveWindowSample:
    app_binary: str
    wm_class: str
    window_title: str
    pid: int
    backend: str


class KWinReceiverInterface(ServiceInterface):
    """Session D-Bus receiver registered as `com.naveen.VibeWatch.Receiver`."""

    def __init__(self) -> None:
        if HAS_DBUS_NEXT:
            super().__init__(DBUS_INTERFACE_NAME)
        self.caption: str = ""
        self.resource_class: str = ""
        self.pid: int = 0
        self.last_received_ts: float = 0.0

    @method()
    def ReportActiveWindow(self, caption: "s", resource_class: "s", pid: "i"):  # type: ignore[valid-type]
        self.caption = str(caption or "")
        self.resource_class = str(resource_class or "")
        self.pid = int(pid or 0)
        self.last_received_ts = time.monotonic()


class KWinDBusCollector:
    """
    Tier 1 — Native KDE Plasma 6 Wayland Collector using KWin Scripting D-Bus Bridge.
    Registers `com.naveen.VibeWatch.Receiver` on the session bus and loads a persistent
    KWin script via `org.kde.kwin.Scripting.loadScript` + `start`.
    """

    def __init__(self) -> None:
        self.bus: Optional[Any] = None
        self.receiver: Optional[KWinReceiverInterface] = None
        self.scripting_iface: Optional[Any] = None
        self._persistent_script_path: Optional[Path] = None
        self._oneshot_script_path: Optional[Path] = None
        self._available: bool = False

    async def start(self) -> bool:
        if not HAS_DBUS_NEXT:
            return False
        try:
            self.bus = await MessageBus().connect()
            self.receiver = KWinReceiverInterface()
            self.bus.export(DBUS_OBJECT_PATH, self.receiver)
            await self.bus.request_name(DBUS_SERVICE_NAME)

            introspection = await self.bus.introspect("org.kde.KWin", "/Scripting")
            proxy = self.bus.get_proxy_object("org.kde.KWin", "/Scripting", introspection)
            self.scripting_iface = proxy.get_interface("org.kde.kwin.Scripting")

            script_dir = Path(tempfile.gettempdir()) / f"vibewatch-{os.getuid()}"
            script_dir.mkdir(parents=True, exist_ok=True)
            self._persistent_script_path = script_dir / "kwin_bridge.js"
            self._oneshot_script_path = script_dir / "kwin_oneshot.js"
            self._persistent_script_path.write_text(KWIN_SCRIPT_TEMPLATE, encoding="utf-8")
            self._oneshot_script_path.write_text(KWIN_ONESHOT_SCRIPT, encoding="utf-8")

            await self._load_and_start(self._persistent_script_path, "vibewatch_bridge")
            self._available = True
            return True
        except Exception:
            self._available = False
            return False

    async def _load_and_start(self, script_path: Path, plugin_name: str) -> None:
        if self.scripting_iface is None or self.bus is None:
            return
        try:
            # Unload previous instance if still loaded
            try:
                await self.scripting_iface.call_unload_script(plugin_name)
            except Exception:
                pass
            script_id = await self.scripting_iface.call_load_script(str(script_path), plugin_name)
            if isinstance(script_id, int) and script_id >= 0:
                await self.scripting_iface.call_start()
        except Exception:
            pass

    async def poll(self) -> Optional[ActiveWindowSample]:
        if not self._available or self.receiver is None:
            return None

        # If no push received in the last 10s, trigger a lightweight one-shot probe
        if time.monotonic() - self.receiver.last_received_ts > 10.0 and self._oneshot_script_path:
            await self._load_and_start(self._oneshot_script_path, "vibewatch_probe")
            await asyncio.sleep(0.08)

        if self.receiver.last_received_ts <= 0.0:
            return None

        app_bin = resolve_pid_binary(
            pid=self.receiver.pid,
            resource_class=self.receiver.resource_class,
            caption=self.receiver.caption,
        )
        return ActiveWindowSample(
            app_binary=app_bin,
            wm_class=self.receiver.resource_class or app_bin,
            window_title=self.receiver.caption,
            pid=self.receiver.pid,
            backend="kwin-dbus",
        )

    async def query_afk(self) -> Optional[Tuple[bool, int]]:
        """
        Query `org.freedesktop.ScreenSaver` over the session D-Bus:
        returns `(is_afk, idle_ms)` where `is_afk = locked or idle_ms >= 180_000`.
        """
        if self.bus is None:
            return None
        try:
            intro = await self.bus.introspect(
                "org.freedesktop.ScreenSaver", "/org/freedesktop/ScreenSaver"
            )
            proxy = self.bus.get_proxy_object(
                "org.freedesktop.ScreenSaver", "/org/freedesktop/ScreenSaver", intro
            )
            ss = proxy.get_interface("org.freedesktop.ScreenSaver")
            idle_ms = int(await ss.call_get_session_idle_time())
            is_locked = bool(await ss.call_get_active())
            return (is_locked or idle_ms >= AFK_THRESHOLD_MS, idle_ms)
        except Exception:
            return None

    async def stop(self) -> None:
        if self.scripting_iface is not None:
            for name in ("vibewatch_bridge", "vibewatch_probe"):
                try:
                    await self.scripting_iface.call_unload_script(name)
                except Exception:
                    pass
        if self.bus is not None:
            try:
                self.bus.disconnect()
            except Exception:
                pass


def collect_via_kdotool() -> Optional[ActiveWindowSample]:
    """Tier 2 — `kdotool` CLI fallback when D-Bus receiver is unavailable."""
    if not shutil.which("kdotool"):
        return None
    try:
        win_id = subprocess.check_output(
            ["kdotool", "getactivewindow"], text=True, stderr=subprocess.DEVNULL, timeout=1.5
        ).strip()
        if not win_id:
            return None
        title = subprocess.check_output(
            ["kdotool", "getwindowname", win_id], text=True, stderr=subprocess.DEVNULL, timeout=1.5
        ).strip()
        wm_class = subprocess.check_output(
            ["kdotool", "getwindowclassname", win_id], text=True, stderr=subprocess.DEVNULL, timeout=1.5
        ).strip()
        pid_raw = subprocess.check_output(
            ["kdotool", "getwindowpid", win_id], text=True, stderr=subprocess.DEVNULL, timeout=1.5
        ).strip()
        pid = int(pid_raw) if pid_raw.isdigit() else 0
        app_bin = resolve_pid_binary(pid=pid, resource_class=wm_class, caption=title)
        return ActiveWindowSample(
            app_binary=app_bin,
            wm_class=wm_class or app_bin,
            window_title=title,
            pid=pid,
            backend="kdotool",
        )
    except Exception:
        return None


def collect_via_xprop() -> Optional[ActiveWindowSample]:
    """Tier 3 — X11 fallback using `xprop` / `_NET_ACTIVE_WINDOW`."""
    if os.environ.get("XDG_SESSION_TYPE", "").lower() != "x11":
        return None
    if not shutil.which("xprop"):
        return None
    try:
        root_out = subprocess.check_output(
            ["xprop", "-root", "_NET_ACTIVE_WINDOW"], text=True, stderr=subprocess.DEVNULL, timeout=1.5
        )
        m = re.search(r"window id #\s*(0x[0-9a-fA-F]+)", root_out)
        if not m:
            return None
        wid = m.group(1)
        win_out = subprocess.check_output(
            ["xprop", "-id", wid, "WM_CLASS", "_NET_WM_NAME", "WM_NAME", "_NET_WM_PID"],
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=1.5,
        )
        class_match = re.search(r'WM_CLASS\(STRING\)\s*=\s*"[^"]*",\s*"([^"]+)"', win_out)
        title_match = re.search(r'(?:_NET_WM_NAME|WM_NAME)\([^)]+\)\s*=\s*"([^"]*)"', win_out)
        pid_match = re.search(r"_NET_WM_PID\(CARDINAL\)\s*=\s*(\d+)", win_out)

        wm_class = class_match.group(1) if class_match else ""
        title = title_match.group(1) if title_match else ""
        pid = int(pid_match.group(1)) if pid_match else 0
        app_bin = resolve_pid_binary(pid=pid, resource_class=wm_class, caption=title)
        return ActiveWindowSample(
            app_binary=app_bin,
            wm_class=wm_class or app_bin,
            window_title=title,
            pid=pid,
            backend="x11-xprop",
        )
    except Exception:
        return None


def query_afk_cli_fallback() -> Tuple[bool, int]:
    """CLI fallback for `org.freedesktop.ScreenSaver` when dbus-next is unavailable."""
    qdbus = shutil.which("qdbus6") or shutil.which("qdbus")
    if qdbus:
        try:
            idle_raw = subprocess.check_output(
                [qdbus, "org.freedesktop.ScreenSaver", "/org/freedesktop/ScreenSaver", "GetSessionIdleTime"],
                text=True,
                stderr=subprocess.DEVNULL,
                timeout=1.5,
            ).strip()
            active_raw = subprocess.check_output(
                [qdbus, "org.freedesktop.ScreenSaver", "/org/freedesktop/ScreenSaver", "GetActive"],
                text=True,
                stderr=subprocess.DEVNULL,
                timeout=1.5,
            ).strip().lower()
            idle_ms = int(idle_raw) if idle_raw.isdigit() else 0
            locked = active_raw == "true"
            return (locked or idle_ms >= AFK_THRESHOLD_MS, idle_ms)
        except Exception:
            pass
    return (False, 0)


class VibeWatchDaemon:
    """Orchestrates multi-tier Wayland/X11 polling, AFK detection, and SQLite heartbeats."""

    def __init__(self, db_path: Path = DEFAULT_DB_PATH) -> None:
        self.db = ActivityDatabase(db_path=db_path)
        self.categories = CategoryEngine()
        self.kwin = KWinDBusCollector()
        self._running = True

    async def poll_once(self) -> Tuple[Optional[ActiveWindowSample], bool, int]:
        sample = await self.kwin.poll()
        if sample is None:
            sample = collect_via_kdotool()
        if sample is None:
            sample = collect_via_xprop()

        afk_info = await self.kwin.query_afk()
        if afk_info is not None:
            is_afk, idle_ms = afk_info
        else:
            is_afk, idle_ms = query_afk_cli_fallback()

        return (sample, is_afk, idle_ms)

    async def run(self, once: bool = False) -> None:
        await self.kwin.start()

        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, self.request_stop)
            except NotImplementedError:
                pass

        try:
            while self._running:
                now = time.time()
                sample, is_afk, idle_ms = await self.poll_once()

                if is_afk:
                    app_bin = "afk"
                    wm_class = "org.freedesktop.ScreenSaver"
                    title = "Screen Locked / Away"
                    backend = sample.backend if sample else "screensaver"
                elif sample is not None:
                    app_bin = sample.app_binary
                    wm_class = sample.wm_class
                    title = sample.window_title
                    backend = sample.backend
                else:
                    app_bin = "desktop"
                    wm_class = "plasmashell"
                    title = "KDE Plasma Desktop"
                    backend = "fallback"

                action, row_id = self.db.record_heartbeat(
                    now=now,
                    app_binary=app_bin,
                    wm_class=wm_class,
                    window_title=title,
                    is_afk=is_afk,
                    pulsetime=HEARTBEAT_PULSETIME_SECONDS,
                )

                write_daemon_status(
                    state="running",
                    active_app="AFK" if is_afk else app_bin,
                    backend=backend,
                    is_afk=is_afk,
                )

                if once:
                    print(
                        json.dumps(
                            {
                                "action": action,
                                "row_id": row_id,
                                "app_binary": app_bin,
                                "wm_class": wm_class,
                                "window_title": title,
                                "is_afk": is_afk,
                                "idle_ms": idle_ms,
                                "backend": backend,
                            },
                            indent=2,
                        )
                    )
                    break

                await asyncio.sleep(POLL_INTERVAL_SECONDS)
        finally:
            write_daemon_status(state="stopped", active_app="none", backend="none", is_afk=False)
            await self.kwin.stop()

    def request_stop(self) -> None:
        self._running = False


def main() -> None:
    parser = argparse.ArgumentParser(
        description="VibeWatch headless activity & screen-time daemon for KDE Plasma 6 (Wayland)."
    )
    parser.add_argument("--once", action="store_true", help="Poll once, write heartbeat, and exit.")
    parser.add_argument("--install", action="store_true", help="Install systemd --user service & .desktop file.")
    parser.add_argument("--db", type=Path, default=DEFAULT_DB_PATH, help="Custom SQLite database path.")
    args = parser.parse_args()

    if args.install:
        import setup as vw_setup
        vw_setup.install_all()
        return

    daemon = VibeWatchDaemon(db_path=args.db)
    asyncio.run(daemon.run(once=args.once))


if __name__ == "__main__":
    main()
