#!/usr/bin/env python3
"""
VibeWatch Native PyQt6 Dashboard (`dashboard.py`)
Zero-chrome KDE Plasma 6 desktop viewer reading directly from `~/.local/share/vibewatch/activity.db`.

Design System (`DESKTOP-STYLE.md`):
- Dark Mode (Default): canvas #141414, card #1B1B1D, bar_bg #242428, border #2C2C30,
  fg #E0E0E0, meta #585858, accent_primary #88C0D0, accent_secondary #826cb6, success #98C379.
- Light Mode (Ctrl+Shift+D): canvas #f2f2f0, card #ffffff, bar_bg #e4e4e2, border #d4d4d0,
  fg #1e1e1e, meta #888888, accent_primary #2563EB.
- Typography: JetBrains Mono for metrics/telemetry, Plus Jakarta Sans / Inter / Roboto for labels.
- Dynamic Zoom: Ctrl+= / Ctrl+- / Ctrl+0 (8pt–48pt).
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Set

from vibewatch_core import (
    DEFAULT_CATEGORIES_PATH,
    DEFAULT_DB_PATH,
    ActivityDatabase,
    AnalyticsSnapshot,
    AppBreakdown,
    CategoryBreakdown,
    CategoryEngine,
    TimelineSegment,
    compute_analytics,
    date_range_bounds,
    ensure_venv,
    format_duration,
    read_daemon_status,
)

# Self-healing .venv check before PyQt6 import
ensure_venv(Path(__file__))

from PyQt6.QtCore import QEvent, QPoint, QRect, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import (
    QColor,
    QCursor,
    QFont,
    QKeyEvent,
    QKeySequence,
    QMouseEvent,
    QPainter,
    QPen,
    QShortcut,
)
from PyQt6.QtWidgets import (
    QApplication,
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QToolTip,
    QVBoxLayout,
    QWidget,
)


THEMES: Dict[str, Dict[str, str]] = {
    "dark": {
        "canvas": "#141414",
        "card": "#1B1B1D",
        "bar_bg": "#242428",
        "border": "#2C2C30",
        "fg": "#E0E0E0",
        "meta": "#585858",
        "meta_soft": "#8A8A8E",
        "accent_primary": "#88C0D0",
        "accent_secondary": "#826cb6",
        "success": "#98C379",
        "hover": "#222226",
        "afk_gap": "#1F1F23",
    },
    "light": {
        "canvas": "#f2f2f0",
        "card": "#ffffff",
        "bar_bg": "#e4e4e2",
        "border": "#d4d4d0",
        "fg": "#1e1e1e",
        "meta": "#888888",
        "meta_soft": "#666666",
        "accent_primary": "#2563EB",
        "accent_secondary": "#6D28D9",
        "success": "#16A34A",
        "hover": "#eaeae7",
        "afk_gap": "#dcdcd8",
    },
}

MONO_FONT_FAMILIES = ["JetBrains Mono", "Fira Code", "Cascadia Code", "monospace"]
SANS_FONT_FAMILIES = ["Plus Jakarta Sans", "Inter", "Roboto", "sans-serif"]


def make_mono_font(pt: int, bold: bool = False) -> QFont:
    font = QFont(MONO_FONT_FAMILIES[0], pt)
    font.setStyleHint(QFont.StyleHint.Monospace)
    font.setBold(bold)
    return font


def make_sans_font(pt: int, bold: bool = False) -> QFont:
    font = QFont(SANS_FONT_FAMILIES[0], pt)
    font.setBold(bold)
    return font


class ActivityTimelineWidget(QWidget):
    """
    Custom `QPainter` 24-hour horizontal activity timeline (`00:00` to `24:00`).
    Renders color-coded category time blocks, dark gaps for AFK/sleep, and rich
    hover tooltips displaying exact `HH:MM–HH:MM`, `app_binary`, and `window_title`.
    """

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setMouseTracking(True)
        self.setMinimumHeight(88)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._segments: List[TimelineSegment] = []
        self._day_start_ts: float = 0.0
        self._theme: Dict[str, str] = THEMES["dark"]
        self._font_pt: int = 10
        self._hovered_idx: int = -1
        self._bar_rects: List[QRectF] = []

    def set_data(
        self,
        segments: List[TimelineSegment],
        day_start_ts: float,
        theme: Dict[str, str],
        font_pt: int,
    ) -> None:
        self._segments = segments
        self._day_start_ts = day_start_ts
        self._theme = theme
        self._font_pt = font_pt
        self._hovered_idx = -1
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        rect = self.rect()
        pad_x = 12
        track_top = 12
        track_h = 34
        track_w = max(1, rect.width() - pad_x * 2)
        track_rect = QRectF(pad_x, track_top, track_w, track_h)

        # Base timeline track
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(self._theme["bar_bg"]))
        painter.drawRoundedRect(track_rect, 4.0, 4.0)

        # Hour gridlines + 24h segments
        self._bar_rects = []
        day_seconds = 86400.0
        for idx, seg in enumerate(self._segments):
            rel_start = max(0.0, min(day_seconds, seg.start_ts - self._day_start_ts))
            rel_end = max(rel_start, min(day_seconds, seg.end_ts - self._day_start_ts))
            if rel_end <= rel_start:
                self._bar_rects.append(QRectF())
                continue
            x0 = pad_x + (rel_start / day_seconds) * track_w
            x1 = pad_x + (rel_end / day_seconds) * track_w
            seg_w = max(2.0, x1 - x0)
            seg_rect = QRectF(x0, track_top, seg_w, track_h)
            self._bar_rects.append(seg_rect)

            color = QColor(self._theme["afk_gap"] if seg.is_afk else seg.color)
            if idx == self._hovered_idx:
                color = color.lighter(118)
            painter.setBrush(color)
            painter.drawRect(seg_rect)

        # Subtle tick marks and HH:00 labels (00:00 .. 24:00 every 3h)
        tick_pen = QPen(QColor(self._theme["border"]))
        tick_pen.setWidth(1)
        label_pen = QPen(QColor(self._theme["meta_soft"]))
        painter.setFont(make_mono_font(max(8, self._font_pt - 2)))

        for hour in range(0, 25, 3):
            x = pad_x + (hour / 24.0) * track_w
            painter.setPen(tick_pen)
            painter.drawLine(int(x), track_top + track_h + 2, int(x), track_top + track_h + 7)
            painter.setPen(label_pen)
            label = f"{hour:02d}:00"
            fm = painter.fontMetrics()
            tw = fm.horizontalAdvance(label)
            tx = int(x - tw / 2)
            tx = max(pad_x, min(rect.width() - pad_x - tw, tx))
            painter.drawText(tx, track_top + track_h + 22, label)

        # Outer hairline around track
        border_pen = QPen(QColor(self._theme["border"]))
        border_pen.setWidth(1)
        painter.setPen(border_pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(track_rect, 4.0, 4.0)
        painter.end()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        pos = event.position()
        hit = -1
        for idx, r in enumerate(self._bar_rects):
            if not r.isNull() and r.contains(pos):
                hit = idx
                break

        if hit != self._hovered_idx:
            self._hovered_idx = hit
            self.update()

        if hit >= 0:
            seg = self._segments[hit]
            t0 = datetime.fromtimestamp(seg.start_ts).strftime("%H:%M")
            t1 = datetime.fromtimestamp(seg.end_ts).strftime("%H:%M")
            dur = format_duration(seg.end_ts - seg.start_ts)
            title = seg.window_title or seg.app_binary
            tip = f"{t0}–{t1} ({dur})\n{seg.app_binary} · {seg.category}\n{title}"
            QToolTip.showText(event.globalPosition().toPoint(), tip, self)
        else:
            QToolTip.hideText()

    def leaveEvent(self, event) -> None:  # noqa: N802
        self._hovered_idx = -1
        QToolTip.hideText()
        self.update()


class ProgressRowButton(QPushButton):
    """Clickable zero-chrome row with ranked horizontal progress bar."""

    def __init__(
        self,
        label: str,
        duration_text: str,
        percent: float,
        bar_color: str,
        theme: Dict[str, str],
        font_pt: int,
        selected: bool = False,
        expandable: bool = False,
        expanded: bool = False,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.setFlat(True)
        self._percent = max(0.0, min(100.0, percent))
        self._bar_color = bar_color
        self._theme = theme
        self._selected = selected

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(6)

        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.setSpacing(8)

        prefix = ("▾ " if expanded else "▸ ") if expandable else ""
        name_lbl = QLabel(f"{prefix}{label}")
        name_lbl.setFont(make_sans_font(font_pt, bold=selected))
        name_lbl.setStyleSheet(f"color: {theme['fg']}; background: transparent;")
        top.addWidget(name_lbl, 1)

        meta_lbl = QLabel(f"{duration_text}  {percent:4.1f}%")
        meta_lbl.setFont(make_mono_font(max(8, font_pt - 1)))
        meta_lbl.setStyleSheet(f"color: {theme['meta_soft']}; background: transparent;")
        top.addWidget(meta_lbl, 0)

        layout.addLayout(top)

        bar_container = QWidget()
        bar_container.setFixedHeight(6)
        bar_container.setStyleSheet(f"background: {theme['bar_bg']}; border-radius: 3px;")
        bar_fill = QWidget(bar_container)
        bar_fill.setStyleSheet(f"background: {bar_color}; border-radius: 3px;")
        self._bar_container = bar_container
        self._bar_fill = bar_fill
        layout.addWidget(bar_container)

        border_color = theme["accent_primary"] if selected else "transparent"
        bg_color = theme["hover"] if selected else "transparent"
        self.setStyleSheet(
            f"QPushButton {{ background: {bg_color}; border: 1px solid {border_color}; border-radius: 6px; text-align: left; }}"
            f"QPushButton:hover {{ background: {theme['hover']}; }}"
        )

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        w = self._bar_container.width()
        fill_w = max(4, int(w * (self._percent / 100.0))) if self._percent > 0 else 0
        self._bar_fill.setGeometry(0, 0, fill_w, self._bar_container.height())


class CategoryEditorDialog(QDialog):
    """Inline `categories.json` rule editor (`Ctrl+E`) with live validation and immediate reload."""

    def __init__(self, categorizer: CategoryEngine, theme: Dict[str, str], font_pt: int, parent=None) -> None:
        super().__init__(parent)
        self.categorizer = categorizer
        self.setWindowTitle("Edit categories.json")
        self.resize(640, 480)
        self.setStyleSheet(
            f"QDialog {{ background: {theme['card']}; color: {theme['fg']}; border: 1px solid {theme['border']}; }}"
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        header = QLabel(f"Categories Rules — {categorizer.path}")
        header.setFont(make_sans_font(font_pt + 1, bold=True))
        header.setStyleSheet(f"color: {theme['fg']};")
        layout.addWidget(header)

        self.editor = QPlainTextEdit()
        self.editor.setFont(make_mono_font(font_pt))
        self.editor.setPlainText(categorizer.read_raw_json())
        self.editor.setStyleSheet(
            f"QPlainTextEdit {{ background: {theme['canvas']}; color: {theme['fg']}; "
            f"border: 1px solid {theme['border']}; border-radius: 6px; padding: 10px; }}"
        )
        layout.addWidget(self.editor, 1)

        self.error_lbl = QLabel("")
        self.error_lbl.setStyleSheet("color: #E06C75;")
        self.error_lbl.setWordWrap(True)
        layout.addWidget(self.error_lbl)

        btn_row = QHBoxLayout()
        btn_row.addStretch(1)
        cancel_btn = QPushButton("Cancel (Esc)")
        save_btn = QPushButton("Save & Reload")
        cancel_btn.clicked.connect(self.reject)
        save_btn.clicked.connect(self._on_save)
        for btn, primary in ((cancel_btn, False), (save_btn, True)):
            btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
            btn.setFont(make_sans_font(font_pt, bold=primary))
            if primary:
                btn.setStyleSheet(
                    f"QPushButton {{ background: {theme['accent_primary']}; color: #141414; "
                    f"border: none; border-radius: 6px; padding: 6px 14px; }}"
                )
            else:
                btn.setStyleSheet(
                    f"QPushButton {{ background: {theme['bar_bg']}; color: {theme['fg']}; "
                    f"border: 1px solid {theme['border']}; border-radius: 6px; padding: 6px 14px; }}"
                )
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(save_btn)
        layout.addLayout(btn_row)

    def _on_save(self) -> None:
        try:
            self.categorizer.save_raw_json(self.editor.toPlainText())
            self.accept()
        except Exception as exc:
            self.error_lbl.setText(f"Invalid categories.json: {exc}")


class ShortcutsOverlay(QDialog):
    """Compact `F1` keyboard shortcuts overlay."""

    SHORTCUTS = [
        ("Left / Right", "Step backward / forward by 1 day"),
        ("T", "Jump back to Today"),
        ("1 / 2 / 3", "Switch between Day, 7 Days, and 30 Days"),
        ("A", "Toggle Include AFK"),
        ("Ctrl + E", "Open inline categories.json rule editor"),
        ("Ctrl + R / F5", "Refresh data from SQLite"),
        ("Ctrl + Shift + D", "Toggle Dark / Light theme"),
        ("Ctrl + = / - / 0", "Zoom UI font size (8pt–48pt)"),
        ("F11 / Ctrl+Shift+F", "Toggle frameless window mode (Alt+Drag to move)"),
        ("F1", "Toggle this shortcuts overlay"),
        ("Escape", "Dismiss filter/overlay, or exit at root view"),
        ("Ctrl + Q", "Immediate exit"),
    ]

    def __init__(self, theme: Dict[str, str], font_pt: int, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("VibeWatch Shortcuts")
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Dialog)
        self.setStyleSheet(
            f"QDialog {{ background: {theme['card']}; color: {theme['fg']}; "
            f"border: 1px solid {theme['border']}; border-radius: 8px; }}"
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(8)

        title = QLabel("Keyboard Shortcuts")
        title.setFont(make_sans_font(font_pt + 2, bold=True))
        layout.addWidget(title)

        for key, desc in self.SHORTCUTS:
            row = QHBoxLayout()
            k_lbl = QLabel(key)
            k_lbl.setFont(make_mono_font(max(8, font_pt - 1), bold=True))
            k_lbl.setStyleSheet(f"color: {theme['accent_primary']};")
            k_lbl.setFixedWidth(160)
            d_lbl = QLabel(desc)
            d_lbl.setFont(make_sans_font(max(8, font_pt - 1)))
            d_lbl.setStyleSheet(f"color: {theme['fg']};")
            row.addWidget(k_lbl)
            row.addWidget(d_lbl, 1)
            layout.addLayout(row)

        hint = QLabel("Press F1 or Escape to close")
        hint.setFont(make_mono_font(max(8, font_pt - 2)))
        hint.setStyleSheet(f"color: {theme['meta']}; padding-top: 6px;")
        layout.addWidget(hint)


class VibeWatchWindow(QMainWindow):
    """Main zero-chrome VibeWatch PyQt6 Dashboard Window."""

    EDGE_MARGIN = 8

    def __init__(self, db_path: Path = DEFAULT_DB_PATH) -> None:
        super().__init__()
        self.setWindowTitle("VibeWatch")
        self.resize(1240, 820)
        self.setMinimumSize(860, 620)

        self.db = ActivityDatabase(db_path=db_path)
        self.categorizer = CategoryEngine(DEFAULT_CATEGORIES_PATH)

        # Interactive UI state
        self.theme_name: str = "dark"
        self.font_pt: int = 11
        self.anchor_date: datetime = datetime.now()
        self.range_mode: str = "day"  # "day" | "7d" | "30d"
        self.include_afk: bool = False
        self.selected_category: Optional[str] = None
        self.expanded_apps: Set[str] = set()
        self.frameless: bool = False
        self._shortcuts_dialog: Optional[ShortcutsOverlay] = None
        self._drag_pos: Optional[QPoint] = None
        self._resize_edges: Qt.Edge = Qt.Edge(0)

        self._build_ui()
        self._register_shortcuts()
        self.apply_theme()
        self.refresh_data()

        # Lightweight 5s timer to hot-reload categories.json & daemon status anchor
        self._poll_timer = QTimer(self)
        self._poll_timer.timeout.connect(self._on_background_tick)
        self._poll_timer.start(5000)

    def _build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        self.root_layout = QVBoxLayout(root)
        self.root_layout.setContentsMargins(24, 24, 24, 18)
        self.root_layout.setSpacing(16)

        # 1. Top Control Strip (date selector, range selector, Include AFK, Edit Categories)
        top_bar = QHBoxLayout()
        top_bar.setSpacing(10)

        self.prev_btn = QPushButton("◄")
        self.date_lbl = QLabel("Today")
        self.next_btn = QPushButton("►")
        self.prev_btn.clicked.connect(lambda: self.step_day(-1))
        self.next_btn.clicked.connect(lambda: self.step_day(1))
        top_bar.addWidget(self.prev_btn)
        top_bar.addWidget(self.date_lbl)
        top_bar.addWidget(self.next_btn)
        top_bar.addStretch(1)

        self.range_btns: Dict[str, QPushButton] = {}
        for mode, text in (("day", "Day"), ("7d", "7 Days"), ("30d", "30 Days")):
            btn = QPushButton(text)
            btn.clicked.connect(lambda _checked=False, m=mode: self.set_range_mode(m))
            self.range_btns[mode] = btn
            top_bar.addWidget(btn)

        self.afk_btn = QPushButton("Include AFK")
        self.afk_btn.clicked.connect(self.toggle_afk)
        top_bar.addWidget(self.afk_btn)

        self.edit_cat_btn = QPushButton("Edit Categories")
        self.edit_cat_btn.clicked.connect(self.open_category_editor)
        top_bar.addWidget(self.edit_cat_btn)
        self.root_layout.addLayout(top_bar)

        # Summary KPI strip (Active Time, Top Category, Top App, AFK Time)
        self.kpi_frame = QFrame()
        kpi_layout = QHBoxLayout(self.kpi_frame)
        kpi_layout.setContentsMargins(16, 12, 16, 12)
        kpi_layout.setSpacing(24)
        self.kpi_values: Dict[str, QLabel] = {}
        self.kpi_labels: Dict[str, QLabel] = {}
        for key, label in (
            ("active", "Active Time"),
            ("top_cat", "Top Category"),
            ("top_app", "Top App"),
            ("afk", "AFK Time"),
        ):
            col = QVBoxLayout()
            col.setSpacing(2)
            l_lbl = QLabel(label)
            v_lbl = QLabel("—")
            self.kpi_labels[key] = l_lbl
            self.kpi_values[key] = v_lbl
            col.addWidget(l_lbl)
            col.addWidget(v_lbl)
            kpi_layout.addLayout(col, 1)
        self.root_layout.addWidget(self.kpi_frame)

        # 2. 24-Hour Activity Timeline Card
        self.timeline_card = QFrame()
        tl_layout = QVBoxLayout(self.timeline_card)
        tl_layout.setContentsMargins(16, 12, 16, 10)
        tl_layout.setSpacing(6)
        self.timeline_header = QLabel("24-Hour Activity Timeline")
        self.timeline_widget = ActivityTimelineWidget()
        tl_layout.addWidget(self.timeline_header)
        tl_layout.addWidget(self.timeline_widget)
        self.root_layout.addWidget(self.timeline_card)

        # 3. Two-Column Breakdown Grid (Left: Top Categories, Right: Top Applications)
        cols = QHBoxLayout()
        cols.setSpacing(16)

        self.cat_card = QFrame()
        cat_card_layout = QVBoxLayout(self.cat_card)
        cat_card_layout.setContentsMargins(16, 14, 16, 14)
        cat_card_layout.setSpacing(10)
        self.cat_header = QLabel("Top Categories")
        cat_card_layout.addWidget(self.cat_header)
        self.cat_scroll = QScrollArea()
        self.cat_scroll.setWidgetResizable(True)
        self.cat_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.cat_list_host = QWidget()
        self.cat_list_layout = QVBoxLayout(self.cat_list_host)
        self.cat_list_layout.setContentsMargins(0, 0, 0, 0)
        self.cat_list_layout.setSpacing(6)
        self.cat_scroll.setWidget(self.cat_list_host)
        cat_card_layout.addWidget(self.cat_scroll, 1)

        self.app_card = QFrame()
        app_card_layout = QVBoxLayout(self.app_card)
        app_card_layout.setContentsMargins(16, 14, 16, 14)
        app_card_layout.setSpacing(10)
        app_hdr_row = QHBoxLayout()
        self.app_header = QLabel("Top Applications")
        self.clear_filter_btn = QPushButton("Clear Filter")
        self.clear_filter_btn.clicked.connect(self.clear_category_filter)
        self.clear_filter_btn.setVisible(False)
        app_hdr_row.addWidget(self.app_header, 1)
        app_hdr_row.addWidget(self.clear_filter_btn)
        app_card_layout.addLayout(app_hdr_row)

        self.app_scroll = QScrollArea()
        self.app_scroll.setWidgetResizable(True)
        self.app_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.app_list_host = QWidget()
        self.app_list_layout = QVBoxLayout(self.app_list_host)
        self.app_list_layout.setContentsMargins(0, 0, 0, 0)
        self.app_list_layout.setSpacing(6)
        self.app_scroll.setWidget(self.app_list_host)
        app_card_layout.addWidget(self.app_scroll, 1)

        cols.addWidget(self.cat_card, 42)
        cols.addWidget(self.app_card, 58)
        self.root_layout.addLayout(cols, 1)

        # 4. Whisper-Quiet Status Anchor (Bottom-Right in #585858)
        footer = QHBoxLayout()
        footer.addStretch(1)
        self.status_anchor = QLabel("daemon: checking · active: — · F1 shortcuts")
        footer.addWidget(self.status_anchor)
        self.root_layout.addLayout(footer)

    def _register_shortcuts(self) -> None:
        bindings = [
            ("Left", lambda: self.step_day(-1)),
            ("Right", lambda: self.step_day(1)),
            ("T", self.jump_today),
            ("1", lambda: self.set_range_mode("day")),
            ("2", lambda: self.set_range_mode("7d")),
            ("3", lambda: self.set_range_mode("30d")),
            ("A", self.toggle_afk),
            ("Ctrl+E", self.open_category_editor),
            ("Ctrl+R", self.refresh_data),
            ("F5", self.refresh_data),
            ("Ctrl+Shift+D", self.toggle_theme),
            ("Ctrl+=", lambda: self.adjust_zoom(1)),
            ("Ctrl++", lambda: self.adjust_zoom(1)),
            ("Ctrl+-", lambda: self.adjust_zoom(-1)),
            ("Ctrl+0", self.reset_zoom),
            ("F11", self.toggle_frameless),
            ("Ctrl+Shift+F", self.toggle_frameless),
            ("F1", self.toggle_shortcuts_overlay),
            ("Escape", self.handle_escape),
            ("Ctrl+Q", self.close),
        ]
        for seq, handler in bindings:
            sc = QShortcut(QKeySequence(seq), self)
            sc.activated.connect(handler)

    def _theme(self) -> Dict[str, str]:
        return THEMES[self.theme_name]

    def apply_theme(self) -> None:
        t = self._theme()
        pt = self.font_pt
        self.setStyleSheet(
            f"QMainWindow, QWidget {{ background: {t['canvas']}; color: {t['fg']}; }}"
            f"QScrollArea, QScrollArea > QWidget > QWidget {{ background: {t['card']}; }}"
        )

        card_css = (
            f"QFrame {{ background: {t['card']}; border: 1px solid {t['border']}; border-radius: 8px; }}"
        )
        for frame in (self.kpi_frame, self.timeline_card, self.cat_card, self.app_card):
            frame.setStyleSheet(card_css)

        btn_base = (
            f"QPushButton {{ background: {t['card']}; color: {t['fg']}; border: 1px solid {t['border']}; "
            f"border-radius: 6px; padding: 5px 12px; }}"
            f"QPushButton:hover {{ background: {t['hover']}; }}"
        )
        btn_active = (
            f"QPushButton {{ background: {t['accent_primary']}; color: {'#141414' if self.theme_name == 'dark' else '#ffffff'}; "
            f"border: 1px solid {t['accent_primary']}; border-radius: 6px; padding: 5px 12px; font-weight: 600; }}"
        )

        for btn in (self.prev_btn, self.next_btn, self.edit_cat_btn, self.clear_filter_btn):
            btn.setFont(make_sans_font(max(8, pt - 1)))
            btn.setStyleSheet(btn_base)
            btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))

        for mode, btn in self.range_btns.items():
            btn.setFont(make_sans_font(max(8, pt - 1), bold=(mode == self.range_mode)))
            btn.setStyleSheet(btn_active if mode == self.range_mode else btn_base)
            btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))

        self.afk_btn.setFont(make_sans_font(max(8, pt - 1), bold=self.include_afk))
        self.afk_btn.setStyleSheet(btn_active if self.include_afk else btn_base)
        self.afk_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))

        self.date_lbl.setFont(make_sans_font(pt + 2, bold=True))
        self.date_lbl.setStyleSheet(f"color: {t['fg']}; padding: 0 8px;")

        for lbl in (self.timeline_header, self.cat_header, self.app_header):
            lbl.setFont(make_sans_font(pt, bold=True))
            lbl.setStyleSheet(f"color: {t['fg']}; border: none;")

        for key, lbl in self.kpi_labels.items():
            lbl.setFont(make_sans_font(max(8, pt - 2)))
            lbl.setStyleSheet(f"color: {t['meta_soft']}; border: none;")
        for key, val in self.kpi_values.items():
            val.setFont(make_mono_font(pt + 4, bold=True))
            accent = t["accent_primary"] if key == "active" else t["fg"]
            val.setStyleSheet(f"color: {accent}; border: none;")

        self.status_anchor.setFont(make_mono_font(max(8, pt - 2)))
        self.status_anchor.setStyleSheet(f"color: {t['meta']};")

    def _clear_layout(self, layout: QVBoxLayout) -> None:
        while layout.count():
            item = layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()

    def _format_anchor_label(self) -> str:
        today = datetime.now().date()
        d = self.anchor_date.date()
        formatted = d.strftime("%a, %b %d")
        if d == today:
            return f"Today · {formatted}"
        if d == today - timedelta(days=1):
            return f"Yesterday · {formatted}"
        return formatted

    def refresh_data(self) -> None:
        self.categorizer.reload_if_changed()
        start_ts, end_ts = date_range_bounds(self.anchor_date, self.range_mode)
        events = self.db.query_events(start_ts, end_ts)
        snap = compute_analytics(
            events=events,
            categorizer=self.categorizer,
            include_afk=self.include_afk,
            category_filter=self.selected_category,
        )

        # Always compute 24-hour timeline for the anchored day
        day_start_ts, day_end_ts = date_range_bounds(self.anchor_date, "day")
        day_events = events if self.range_mode == "day" else self.db.query_events(day_start_ts, day_end_ts)
        day_snap = (
            snap
            if self.range_mode == "day"
            else compute_analytics(day_events, self.categorizer, include_afk=True)
        )

        self.date_lbl.setText(self._format_anchor_label())
        self.kpi_values["active"].setText(format_duration(snap.active_seconds))
        self.kpi_values["top_cat"].setText(snap.top_category)
        self.kpi_values["top_app"].setText(snap.top_app)
        self.kpi_values["afk"].setText(format_duration(snap.afk_seconds))

        t = self._theme()
        self.timeline_widget.set_data(day_snap.timeline, day_start_ts, t, self.font_pt)

        # Left column: Top Categories
        self._clear_layout(self.cat_list_layout)
        if not snap.categories:
            empty = QLabel("No activity recorded for this range.")
            empty.setFont(make_sans_font(self.font_pt - 1))
            empty.setStyleSheet(f"color: {t['meta_soft']}; padding: 12px;")
            self.cat_list_layout.addWidget(empty)
        else:
            for cat in snap.categories:
                row = ProgressRowButton(
                    label=cat.category,
                    duration_text=format_duration(cat.duration),
                    percent=cat.percentage,
                    bar_color=cat.color,
                    theme=t,
                    font_pt=self.font_pt,
                    selected=(self.selected_category == cat.category),
                )
                row.clicked.connect(lambda _c=False, name=cat.category: self.toggle_category_filter(name))
                self.cat_list_layout.addWidget(row)
        self.cat_list_layout.addStretch(1)

        # Right column: Top Applications (Expandable inline window_title breakdown)
        self.clear_filter_btn.setVisible(self.selected_category is not None)
        self.app_header.setText(
            f"Top Applications · {self.selected_category}"
            if self.selected_category
            else "Top Applications"
        )
        self._clear_layout(self.app_list_layout)
        if not snap.apps:
            empty = QLabel("No applications match the current view.")
            empty.setFont(make_sans_font(self.font_pt - 1))
            empty.setStyleSheet(f"color: {t['meta_soft']}; padding: 12px;")
            self.app_list_layout.addWidget(empty)
        else:
            for app in snap.apps:
                is_expanded = app.app_binary in self.expanded_apps
                row = ProgressRowButton(
                    label=app.app_binary,
                    duration_text=format_duration(app.duration),
                    percent=app.percentage,
                    bar_color=app.color,
                    theme=t,
                    font_pt=self.font_pt,
                    expandable=len(app.titles) > 0,
                    expanded=is_expanded,
                )
                row.clicked.connect(lambda _c=False, name=app.app_binary: self.toggle_app_expand(name))
                self.app_list_layout.addWidget(row)

                if is_expanded and app.titles:
                    sub_box = QWidget()
                    sub_box.setStyleSheet(f"background: {t['canvas']}; border-radius: 6px;")
                    sub_layout = QVBoxLayout(sub_box)
                    sub_layout.setContentsMargins(16, 6, 12, 8)
                    sub_layout.setSpacing(4)
                    for item in app.titles[:10]:
                        line = QHBoxLayout()
                        t_lbl = QLabel(item.window_title)
                        t_lbl.setFont(make_sans_font(max(8, self.font_pt - 2)))
                        t_lbl.setStyleSheet(f"color: {t['fg']};")
                        d_lbl = QLabel(f"{format_duration(item.duration)} · {item.percentage:4.1f}%")
                        d_lbl.setFont(make_mono_font(max(8, self.font_pt - 2)))
                        d_lbl.setStyleSheet(f"color: {t['meta_soft']};")
                        line.addWidget(t_lbl, 1)
                        line.addWidget(d_lbl, 0)
                        sub_layout.addLayout(line)
                    self.app_list_layout.addWidget(sub_box)
        self.app_list_layout.addStretch(1)

        self._update_status_anchor()

    def _update_status_anchor(self) -> None:
        status = read_daemon_status()
        state = "running" if status["running"] else "stopped"
        active = status["active_app"] if status["running"] else "idle"
        self.status_anchor.setText(f"daemon: {state} · active: {active} · F1 shortcuts")

    def _on_background_tick(self) -> None:
        if self.categorizer.reload_if_changed():
            self.refresh_data()
        else:
            self._update_status_anchor()

    # --- Actions & Keyboard Handlers ---
    def step_day(self, delta: int) -> None:
        self.anchor_date = self.anchor_date + timedelta(days=delta)
        self.refresh_data()

    def jump_today(self) -> None:
        self.anchor_date = datetime.now()
        self.refresh_data()

    def set_range_mode(self, mode: str) -> None:
        self.range_mode = mode
        self.apply_theme()
        self.refresh_data()

    def toggle_afk(self) -> None:
        self.include_afk = not self.include_afk
        self.apply_theme()
        self.refresh_data()

    def toggle_category_filter(self, category: str) -> None:
        self.selected_category = None if self.selected_category == category else category
        self.refresh_data()

    def clear_category_filter(self) -> None:
        self.selected_category = None
        self.refresh_data()

    def toggle_app_expand(self, app_binary: str) -> None:
        if app_binary in self.expanded_apps:
            self.expanded_apps.remove(app_binary)
        else:
            self.expanded_apps.add(app_binary)
        self.refresh_data()

    def toggle_theme(self) -> None:
        self.theme_name = "light" if self.theme_name == "dark" else "dark"
        self.apply_theme()
        self.refresh_data()

    def adjust_zoom(self, delta: int) -> None:
        self.font_pt = max(8, min(48, self.font_pt + delta))
        self.apply_theme()
        self.refresh_data()

    def reset_zoom(self) -> None:
        self.font_pt = 11
        self.apply_theme()
        self.refresh_data()

    def open_category_editor(self) -> None:
        dlg = CategoryEditorDialog(self.categorizer, self._theme(), self.font_pt, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.refresh_data()

    def toggle_shortcuts_overlay(self) -> None:
        if self._shortcuts_dialog is not None and self._shortcuts_dialog.isVisible():
            self._shortcuts_dialog.close()
            self._shortcuts_dialog = None
            return
        self._shortcuts_dialog = ShortcutsOverlay(self._theme(), self.font_pt, self)
        self._shortcuts_dialog.show()

    def toggle_frameless(self) -> None:
        self.frameless = not self.frameless
        geom = self.geometry()
        self.setWindowFlag(Qt.WindowType.FramelessWindowHint, self.frameless)
        self.setGeometry(geom)
        self.show()

    def handle_escape(self) -> None:
        if self._shortcuts_dialog is not None and self._shortcuts_dialog.isVisible():
            self._shortcuts_dialog.close()
            self._shortcuts_dialog = None
            return
        if self.selected_category is not None:
            self.selected_category = None
            self.refresh_data()
            return
        if self.expanded_apps:
            self.expanded_apps.clear()
            self.refresh_data()
            return
        self.close()

    # --- Frameless Window Alt+Drag Move & 8px Edge Resize ---
    def _edges_at(self, pos: QPoint) -> Qt.Edge:
        edges = Qt.Edge(0)
        m = self.EDGE_MARGIN
        if pos.x() <= m:
            edges |= Qt.Edge.LeftEdge
        elif pos.x() >= self.width() - m:
            edges |= Qt.Edge.RightEdge
        if pos.y() <= m:
            edges |= Qt.Edge.TopEdge
        elif pos.y() >= self.height() - m:
            edges |= Qt.Edge.BottomEdge
        return edges

    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if self.frameless and event.button() == Qt.MouseButton.LeftButton:
            pos = event.position().toPoint()
            edges = self._edges_at(pos)
            handle = self.windowHandle()
            if edges and handle is not None:
                handle.startSystemResize(edges)
                return
            if event.modifiers() & Qt.KeyboardModifier.AltModifier:
                if handle is not None:
                    handle.startSystemMove()
                else:
                    self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if self.frameless and self._drag_pos is not None:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        self._drag_pos = None
        super().mouseReleaseEvent(event)


def main() -> None:
    parser = argparse.ArgumentParser(description="VibeWatch native PyQt6 Activity & Screen-Time Dashboard.")
    parser.add_argument("--install", action="store_true", help="Install systemd --user service & .desktop launcher.")
    parser.add_argument("--db", type=Path, default=DEFAULT_DB_PATH, help="Custom SQLite database path.")
    args = parser.parse_args()

    if args.install:
        import setup as vw_setup
        vw_setup.install_all()
        return

    app = QApplication(sys.argv)
    app.setApplicationName("VibeWatch")
    app.setDesktopFileName("vibewatch")
    window = VibeWatchWindow(db_path=args.db)
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
